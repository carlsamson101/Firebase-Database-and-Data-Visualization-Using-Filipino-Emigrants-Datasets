import React from 'react';
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  Area,
  AreaChart,
  ScatterChart,
  Scatter,
  CartesianGrid,
  Legend,
  ComposedChart,
  RadialBarChart,
  RadialBar
} from "recharts";

export const ChartRenderer = ({ 
  selectedChart, 
  chartData, 
  xAxis, 
  yAxis, 
  groupBy,
  colors, 
  animateCharts, 
  fullscreenChart,
  aggregationType 
}) => {
  if (!chartData.length) {
    return (
      <div className="text-center text-gray-500 py-12">
        <div className="text-6xl mb-4 opacity-30">📊</div>
        <p className="text-lg">No data to display with current filters</p>
        <p className="text-sm">Try adjusting your filters or selecting different columns</p>
      </div>
    );
  }

  const chartHeight = fullscreenChart ? 600 : 400;
  const animationConfig = animateCharts ? { animationDuration: 800 } : false;
  
  const commonProps = {
    width: "100%",
    height: chartHeight,
    ...animationConfig
  };

  switch (selectedChart) {
    case 'comparison':
      return <ComparisonChart {...commonProps} data={chartData} xAxis={xAxis} yAxis={yAxis} colors={colors} animateCharts={animateCharts} aggregationType={aggregationType} />;
    
    case 'composition':
      return <CompositionChart {...commonProps} data={chartData} colors={colors} animateCharts={animateCharts} aggregationType={aggregationType} chartHeight={chartHeight} />;
    
    case 'trends':
      return <TrendsChart {...commonProps} data={chartData} xAxis={xAxis} yAxis={yAxis} colors={colors} animateCharts={animateCharts} />;
    
    case 'distribution':
      return <DistributionChart {...commonProps} data={chartData} xAxis={xAxis} yAxis={yAxis} colors={colors} animateCharts={animateCharts} />;
    
    case 'relationships':
      return <RelationshipsChart {...commonProps} data={chartData} xAxis={xAxis} yAxis={yAxis} colors={colors} animateCharts={animateCharts} />;
    
    case 'geographic':
      return <GeographicChart {...commonProps} data={chartData.slice(0, 20)} yAxis={yAxis} colors={colors} animateCharts={animateCharts} aggregationType={aggregationType} />;
    
    case 'heatmap':
      return <HeatmapChart data={chartData} />;
    
    case 'radial':
      return <RadialChart {...commonProps} data={chartData.slice(0, 8)} yAxis={yAxis} colors={colors} animateCharts={animateCharts} />;
    
    default:
      return <div className="text-center py-8">Select a chart type to visualize your data</div>;
  }
};

const ComparisonChart = ({ data, xAxis, yAxis, colors, animateCharts, aggregationType, ...props }) => (
  <ResponsiveContainer {...props}>
    <BarChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
      <defs>
        <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor={colors[0]} stopOpacity={0.8}/>
          <stop offset="95%" stopColor={colors[0]} stopOpacity={0.3}/>
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
      <XAxis 
        dataKey={xAxis} 
        angle={data.length > 10 ? -45 : 0}
        textAnchor={data.length > 10 ? 'end' : 'middle'}
        height={data.length > 10 ? 80 : 60}
        fontSize={12}
      />
      <YAxis fontSize={12} />
      <Tooltip 
        contentStyle={{ 
          backgroundColor: 'white', 
          border: '1px solid #ccc', 
          borderRadius: '8px',
          boxShadow: '0 4px 6px rgba(0, 0, 0, 0.1)'
        }}
        formatter={(value, name) => [
          `${value.toLocaleString()} (${aggregationType})`,
          yAxis
        ]}
      />
      <Bar 
        dataKey={yAxis} 
        fill="url(#barGradient)"
        radius={[4, 4, 0, 0]}
        animationDuration={animateCharts ? 800 : 0}
      />
    </BarChart>
  </ResponsiveContainer>
);

const CompositionChart = ({ data, colors, animateCharts, aggregationType, chartHeight, ...props }) => (
  <ResponsiveContainer {...props}>
    <PieChart margin={{ top: 20, right: 80, bottom: 20, left: 80 }}>
      <Pie
        data={data}
        dataKey="value"
        nameKey="name"
        cx="50%"
        cy="50%"
        outerRadius={Math.min(chartHeight * 0.3, 150)}
        label={({ name, percentage }) => `${name}: ${percentage.toFixed(1)}%`}
        labelLine={false}
        animationDuration={animateCharts ? 1000 : 0}
      >
        {data.map((_, index) => (
          <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
        ))}
      </Pie>
      <Tooltip 
        formatter={(value, name) => [
          `${value.toLocaleString()} (${aggregationType})`,
          name
        ]}
      />
      <Legend />
    </PieChart>
  </ResponsiveContainer>
);

const TrendsChart = ({ data, xAxis, yAxis, colors, animateCharts, ...props }) => {
  const trendSeries = data.length > 0 ? 
    Object.keys(data[0]).filter(k => k !== xAxis && k !== 'count') : [];
  
  return (
    <ResponsiveContainer {...props}>
      <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
        <defs>
          <linearGradient id="lineGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={colors[0]} stopOpacity={0.3}/>
            <stop offset="95%" stopColor={colors[0]} stopOpacity={0.1}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
        <XAxis dataKey={xAxis} fontSize={12} />
        <YAxis fontSize={12} />
        <Tooltip 
          contentStyle={{ 
            backgroundColor: 'white', 
            border: '1px solid #ccc', 
            borderRadius: '8px' 
          }}
        />
        {trendSeries.length <= 1 ? (
          <>
            <Area 
              type="monotone" 
              dataKey={yAxis} 
              stroke={colors[0]}
              fill="url(#lineGradient)"
              strokeWidth={3}
              dot={{ r: 5, fill: colors[0] }}
              animationDuration={animateCharts ? 1000 : 0}
            />
            <Line 
              type="monotone" 
              dataKey={yAxis} 
              stroke={colors[0]}
              strokeWidth={3}
              dot={{ r: 5 }}
              animationDuration={animateCharts ? 800 : 0}
            />
          </>
        ) : (
          <>
            <Legend />
            {trendSeries.slice(0, 8).map((series, index) => (
              <Line 
                key={series}
                type="monotone" 
                dataKey={series} 
                stroke={colors[index % colors.length]}
                strokeWidth={2}
                dot={{ r: 4 }}
                animationDuration={animateCharts ? 800 : 0}
              />
            ))}
          </>
        )}
      </LineChart>
    </ResponsiveContainer>
  );
};

const DistributionChart = ({ data, xAxis, yAxis, colors, animateCharts, ...props }) => (
  <ResponsiveContainer {...props}>
    <ComposedChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
      <defs>
        <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor={colors[0]} stopOpacity={0.6}/>
          <stop offset="95%" stopColor={colors[0]} stopOpacity={0.1}/>
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
      <XAxis dataKey={xAxis} fontSize={12} />
      <YAxis fontSize={12} />
      <Tooltip />
      <Area 
        type="monotone" 
        dataKey={yAxis} 
        stroke={colors[0]} 
        fill="url(#areaGradient)" 
        strokeWidth={2}
        animationDuration={animateCharts ? 1000 : 0}
      />
      <Bar 
        dataKey="density" 
        fill={colors[1]} 
        opacity={0.3}
        animationDuration={animateCharts ? 800 : 0}
      />
    </ComposedChart>
  </ResponsiveContainer>
);

const RelationshipsChart = ({ data, xAxis, yAxis, colors, animateCharts, ...props }) => (
  <ResponsiveContainer {...props}>
    <ScatterChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
      <XAxis dataKey="x" name={xAxis} fontSize={12} />
      <YAxis dataKey="y" name={yAxis} fontSize={12} />
      <Tooltip cursor={{ strokeDasharray: '3 3' }} content={({ active, payload }) => {
        if (active && payload && payload.length) {
          const data = payload[0].payload;
          return (
            <div className="bg-white p-4 border rounded-lg shadow-lg">
              <p className="font-semibold text-gray-800">{data.name}</p>
              <p className="text-sm text-gray-600">{`${xAxis}: ${data.x.toLocaleString()}`}</p>
              <p className="text-sm text-gray-600">{`${yAxis}: ${data.y.toLocaleString()}`}</p>
              <p className="text-sm text-gray-600">{`Category: ${data.category}`}</p>
            </div>
          );
        }
        return null;
      }} />
      <Scatter 
        dataKey="y" 
        fill={colors[0]}
        animationDuration={animateCharts ? 1000 : 0}
      />
    </ScatterChart>
  </ResponsiveContainer>
);

const GeographicChart = ({ data, yAxis, colors, animateCharts, aggregationType, ...props }) => (
  <ResponsiveContainer {...props}>
    <BarChart data={data} layout="horizontal" margin={{ top: 20, right: 30, left: 120, bottom: 20 }}>
      <defs>
        <linearGradient id="geoGradient" x1="0" y1="0" x2="1" y2="0">
          <stop offset="5%" stopColor={colors[2]} stopOpacity={0.8}/>
          <stop offset="95%" stopColor={colors[2]} stopOpacity={0.4}/>
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
      <XAxis type="number" fontSize={12} />
      <YAxis dataKey="region" type="category" width={120} fontSize={11} />
      <Tooltip formatter={(value) => [value.toLocaleString(), `${yAxis} (${aggregationType})`]} />
      <Bar 
        dataKey="value" 
        fill="url(#geoGradient)"
        radius={[0, 4, 4, 0]}
        animationDuration={animateCharts ? 800 : 0}
      />
    </BarChart>
  </ResponsiveContainer>
);

const RadialChart = ({ data, yAxis, colors, animateCharts, ...props }) => (
  <ResponsiveContainer {...props}>
    <RadialBarChart cx="50%" cy="50%" innerRadius="20%" outerRadius="80%" data={data}>
      <RadialBar 
        dataKey="value" 
        cornerRadius={10} 
        fill={colors[0]}
        animationDuration={animateCharts ? 1000 : 0}
      />
      <Tooltip formatter={(value) => [value.toLocaleString(), yAxis]} />
      <Legend />
    </RadialBarChart>
  </ResponsiveContainer>
);

const HeatmapChart = ({ data }) => {
  const heatmapMatrix = {};
  const xValues = [...new Set(data.map(d => d.x))];
  const yValues = [...new Set(data.map(d => d.y))];
  
  data.forEach(d => {
    if (!heatmapMatrix[d.y]) heatmapMatrix[d.y] = {};
    heatmapMatrix[d.y][d.x] = d.value;
  });

  return (
    <div className="overflow-x-auto">
      <div className="inline-block min-w-full">
        <div className="grid gap-1 p-4" style={{ 
          gridTemplateColumns: `150px repeat(${xValues.length}, 1fr)`,
          gridTemplateRows: `50px repeat(${yValues.length}, 1fr)`
        }}>
          <div></div>
          {xValues.map(x => (
            <div key={x} className="text-xs font-medium text-center p-2 bg-gray-100 rounded">
              {x}
            </div>
          ))}
          {yValues.map(y => (
            <React.Fragment key={y}>
              <div className="text-xs font-medium p-2 bg-gray-100 rounded flex items-center">
                {y}
              </div>
              {xValues.map(x => {
                const value = heatmapMatrix[y]?.[x] || 0;
                const maxValue = Math.max(...data.map(d => d.value));
                const intensity = maxValue > 0 ? value / maxValue : 0;
                return (
                  <div
                    key={`${x}-${y}`}
                    className="aspect-square rounded text-xs font-medium flex items-center justify-center text-white"
                    style={{
                      backgroundColor: `rgba(52, 152, 219, ${intensity})`,
                      minHeight: '40px'
                    }}
                    title={`${x} × ${y}: ${value.toLocaleString()}`}
                  >
                    {value > 0 ? value.toLocaleString() : ''}
                  </div>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};