// src/components/DataTable.jsx
import React, { useEffect, useState, useMemo } from "react";
import {
  collection,
  getDocs,
  addDoc,
  updateDoc,
  deleteDoc,
  doc,
} from "firebase/firestore";
import { db } from "../firebase";

function DataTable({ collectionName }) {
  const [rows, setRows] = useState([]);
  const [newRow, setNewRow] = useState({});
  const [loading, setLoading] = useState(true);
  const [editingCell, setEditingCell] = useState({ rowId: null, column: null });
  const [editValue, setEditValue] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [sortConfig, setSortConfig] = useState({ column: null, direction: 'asc' });
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [showAddForm, setShowAddForm] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const fetchData = async () => {
  setLoading(true);
  try {
    const snapshot = await getDocs(collection(db, collectionName));
    const data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

    // Smart sorting: EDUCATIONAL ATTAINMENT first, then YEAR, then alphabetical, TOTAL last
    data.sort((a, b) => {
      const aYear = a.YEAR || a.Year || a.year;
      const bYear = b.YEAR || b.Year || b.year;

      const aEdu = a["EDUCATIONAL ATTAINMENT"];
      const bEdu = b["EDUCATIONAL ATTAINMENT"];

      // ✅ Rule 1: EDUCATIONAL ATTAINMENT always comes first
      if (aEdu && !bEdu) return -1;
      if (!aEdu && bEdu) return 1;

      // ✅ Rule 2: TOTAL always comes last
      if (String(aYear).toUpperCase() === "TOTAL") return 1;
      if (String(bYear).toUpperCase() === "TOTAL") return -1;

      // ✅ Rule 3: Compare numbers if both are valid years
      if (aYear && bYear && !isNaN(Number(aYear)) && !isNaN(Number(bYear))) {
        return Number(aYear) - Number(bYear);
      }

      // ✅ Rule 4: Fallback alphabetical
      return String(aYear || "").localeCompare(String(bYear || ""));
    });

    setRows(data);

    // Initialize newRow structure
    if (data.length > 0 && Object.keys(newRow).length === 0) {
      const initRow = {};
      Object.keys(data[0]).forEach((col) => {
        if (col !== "id") initRow[col] = "";
      });
      setNewRow(initRow);
    }
  } catch (error) {
    console.error("Error fetching data:", error);
  }
  setLoading(false);
};


  useEffect(() => {
    if (collectionName) {
      fetchData();
    }
  }, [collectionName]);

  const handleAdd = async () => {
    if (Object.values(newRow).some(val => val.trim() !== "")) {
      try {
        await addDoc(collection(db, collectionName), newRow);
        setNewRow(Object.keys(newRow).reduce((acc, key) => ({ ...acc, [key]: "" }), {}));
        setShowAddForm(false);
        fetchData();
      } catch (error) {
        console.error("Error adding document:", error);
      }
    }
  };

  const handleEdit = (rowId, column, currentValue) => {
    setEditingCell({ rowId, column });
    setEditValue(currentValue || "");
  };

  const handleSaveEdit = async () => {
    if (editingCell.rowId && editingCell.column) {
      try {
        const ref = doc(db, collectionName, editingCell.rowId);
        await updateDoc(ref, { [editingCell.column]: editValue });
        setEditingCell({ rowId: null, column: null });
        setEditValue("");
        fetchData();
      } catch (error) {
        console.error("Error updating document:", error);
      }
    }
  };

  const handleCancelEdit = () => {
    setEditingCell({ rowId: null, column: null });
    setEditValue("");
  };

  const handleDelete = async (id) => {
    if (deleteConfirm === id) {
      try {
        const ref = doc(db, collectionName, id);
        await deleteDoc(ref);
        setDeleteConfirm(null);
        fetchData();
      } catch (error) {
        console.error("Error deleting document:", error);
      }
    } else {
      setDeleteConfirm(id);
      setTimeout(() => setDeleteConfirm(null), 3000); // Auto-cancel after 3s
    }
  };

  const handleSort = (column) => {
    setSortConfig(prev => ({
      column,
      direction: prev.column === column && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  // Get column configuration
  const columns = useMemo(() => {
    if (rows.length === 0) return [];
    
    const keys = Object.keys(rows[0]).filter((k) => k !== "id");
    const yearCol = keys.find(k => k.toUpperCase().includes('YEAR'));
    const totalCol = keys.find(k => k.toUpperCase().includes('TOTAL'));
    
    return [
      ...(yearCol ? [yearCol] : []),
      ...keys.filter((k) => k !== yearCol && k !== totalCol),
      ...(totalCol ? [totalCol] : [])
    ];
  }, [rows]);

  // Filter and sort data
  const filteredAndSortedRows = useMemo(() => {
    let filtered = rows.filter(row =>
      columns.some(col => 
        String(row[col] || '').toLowerCase().includes(searchTerm.toLowerCase())
      )
    );

    if (sortConfig.column) {
      filtered.sort((a, b) => {
        const aVal = a[sortConfig.column];
        const bVal = b[sortConfig.column];
        
        // Handle TOTAL rows
        if (String(aVal).toUpperCase() === "TOTAL") return 1;
        if (String(bVal).toUpperCase() === "TOTAL") return -1;
        
        // Numeric comparison
        const aNum = Number(aVal);
        const bNum = Number(bVal);
        if (!isNaN(aNum) && !isNaN(bNum)) {
          return sortConfig.direction === 'asc' ? aNum - bNum : bNum - aNum;
        }
        
        // String comparison
        const comparison = String(aVal || '').localeCompare(String(bVal || ''));
        return sortConfig.direction === 'asc' ? comparison : -comparison;
      });
    }

    return filtered;
  }, [rows, searchTerm, sortConfig, columns]);

  // Pagination
  const paginatedRows = useMemo(() => {
    const startIndex = (currentPage - 1) * rowsPerPage;
    return filteredAndSortedRows.slice(startIndex, startIndex + rowsPerPage);
  }, [filteredAndSortedRows, currentPage, rowsPerPage]);

  const totalPages = Math.ceil(filteredAndSortedRows.length / rowsPerPage);

  const formatCellValue = (value, column) => {
    if (value === null || value === undefined) return "";
    
    // Format numbers with commas if they're large
    if (!isNaN(Number(value)) && Number(value) > 999) {
      return Number(value).toLocaleString();
    }
    
    return String(value);
  };

  if (loading) {
    return (
      <div style={{ 
        padding: "40px", 
        textAlign: "center", 
        fontSize: "25px", 
        color: "#6b7280" 
      }}>
        <div style={{ 
          display: "inline-block", 
          width: "20px", 
          height: "20px", 
          border: "2px solid #e5e7eb", 
          borderTop: "2px solid #3b82f6", 
          borderRadius: "50%", 
          animation: "spin 1s linear infinite",
          marginRight: "12px" 
        }}></div>
        Loading data...
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div style={{ padding: "0px" }}>
      {/* Header */}
      <div style={{ 
        display: "flex", 
        justifyContent: "space-between", 
        alignItems: "center", 
        marginBottom: "24px",
        flexWrap: "wrap",
        gap: "16px"
      }}>
        <div>
          <h2 style={{ 
            margin: "0 0 8px 0", 
            fontSize: "24px", 
            fontWeight: "700", 
            color: "#1f2937" 
          }}>
            {collectionName}
          </h2>
          <p style={{ 
            margin: 0, 
            color: "#6b7280", 
            fontSize: "18px" 
          }}>
            {filteredAndSortedRows.length} records total
          </p>
        </div>
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          style={{
            backgroundColor: showAddForm ? "#ef4444" : "#10b981",
            color: "white",
            border: "none",
            padding: "10px 20px",
            borderRadius: "8px",
            fontSize: "18px",
            fontWeight: "600",
            cursor: "pointer",
            transition: "all 0.2s",
            display: "flex",
            alignItems: "center",
            gap: "8px"
          }}
          onMouseEnter={(e) => {
            e.target.style.backgroundColor = showAddForm ? "#dc2626" : "#059669";
            e.target.style.transform = "translateY(-1px)";
          }}
          onMouseLeave={(e) => {
            e.target.style.backgroundColor = showAddForm ? "#ef4444" : "#10b981";
            e.target.style.transform = "translateY(0px)";
          }}
        >
          {showAddForm ? "Cancel" : "Add New Record"}
        </button>
      </div>

      {/* Search and Controls */}
      <div style={{ 
        display: "flex", 
        justifyContent: "space-between", 
        alignItems: "center", 
        marginBottom: "20px",
        flexWrap: "wrap",
        gap: "12px"
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <input
            type="text"
            placeholder="Search records..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={{
              padding: "10px 16px",
              border: "1px solid #d1d5db",
              borderRadius: "8px",
              fontSize: "14px",
              width: "250px",
              outline: "none",
              transition: "border-color 0.2s"
            }}
            onFocus={(e) => e.target.style.borderColor = "#3b82f6"}
            onBlur={(e) => e.target.style.borderColor = "#d1d5db"}
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              style={{
                background: "none",
                border: "none",
                color: "#6b7280",
                cursor: "pointer",
                fontSize: "18px"
              }}
            >
              ✕
            </button>
          )}
        </div>
        
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <label style={{ fontSize: "14px", color: "#374151" }}>Rows per page:</label>
          <select
            value={rowsPerPage}
            onChange={(e) => {
              setRowsPerPage(Number(e.target.value));
              setCurrentPage(1);
            }}
            style={{
              padding: "6px 12px",
              border: "1px solid #d1d5db",
              borderRadius: "6px",
              fontSize: "14px",
              backgroundColor: "white"
            }}
          >
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={25}>25</option>
            <option value={50}>50</option>
            <option value={100}>100</option>
          </select>
        </div>
      </div>

      {/* Add Form */}
      {showAddForm && (
        <div style={{
          backgroundColor: "#f9fafb",
          border: "1px solid #e5e7eb",
          borderRadius: "12px",
          padding: "20px",
          marginBottom: "20px"
        }}>
          <h3 style={{ 
            margin: "0 0 16px 0", 
            fontSize: "18px", 
            fontWeight: "600", 
            color: "#1f2937" 
          }}>
            Add New Record
          </h3>
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: "12px",
            marginBottom: "16px"
          }}>
            {columns.map((col) => (
              <div key={col}>
                <label style={{
                  display: "block",
                  fontSize: "12px",
                  fontWeight: "500",
                  color: "#374151",
                  marginBottom: "4px",
                  textTransform: "uppercase",
                  letterSpacing: "0.5px"
                }}>
                  {col}
                </label>
                <input
                  type="text"
                  placeholder={`Enter ${col}...`}
                  value={newRow[col] || ""}
                  onChange={(e) =>
                    setNewRow({ ...newRow, [col]: e.target.value })
                  }
                  style={{
                    width: "100%",
                    padding: "10px 12px",
                    border: "1px solid #d1d5db",
                    borderRadius: "6px",
                    fontSize: "14px",
                    outline: "none",
                    transition: "border-color 0.2s"
                  }}
                  onFocus={(e) => e.target.style.borderColor = "#3b82f6"}
                  onBlur={(e) => e.target.style.borderColor = "#d1d5db"}
                />
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: "12px" }}>
            <button
              onClick={handleAdd}
              disabled={!Object.values(newRow).some(val => val && val.trim() !== "")}
              style={{
                backgroundColor: "#10b981",
                color: "white",
                border: "none",
                padding: "10px 20px",
                borderRadius: "6px",
                fontSize: "14px",
                fontWeight: "500",
                cursor: "pointer",
                opacity: Object.values(newRow).some(val => val && val.trim() !== "") ? 1 : 0.5
              }}
            >
              Add Record
            </button>
            <button
              onClick={() => {
                setShowAddForm(false);
                setNewRow(Object.keys(newRow).reduce((acc, key) => ({ ...acc, [key]: "" }), {}));
              }}
              style={{
                backgroundColor: "#6b7280",
                color: "white",
                border: "none",
                padding: "10px 20px",
                borderRadius: "6px",
                fontSize: "14px",
                fontWeight: "500",
                cursor: "pointer"
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

        {/* Table */}
        <div style={{
      backgroundColor: "white",
      borderRadius: "12px",
      border: "1px solid #e5e7eb",
      boxShadow: "0 1px 3px rgba(0,0,0,0.08)",
      padding: 12,
      width: "100%",
      maxWidth: "80vw",     // never exceed viewport width
      overflowX: "auto",     // enable horizontal scroll
      overflowY: "hidden",
      boxSizing: "border-box"
        }}>
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ backgroundColor: "#f9fafb" }}>
                  {columns.map((col) => (
                    <th
                      key={col}
                      onClick={() => handleSort(col)}
                    style={{
                      padding: "16px",
                      textAlign: "left",
                      fontSize: "12px",
                      fontWeight: "600",
                      color: "#374151",
                      textTransform: "uppercase",
                      letterSpacing: "0.5px",
                      borderBottom: "1px solid #e5e7eb",
                      cursor: "pointer",
                      userSelect: "none",
                      position: "relative",
                    }}
                    onMouseEnter={(e) => e.target.style.backgroundColor = "#f3f4f6"}
                    onMouseLeave={(e) => e.target.style.backgroundColor = "transparent"}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                      {col}
                      <span style={{ 
                        opacity: sortConfig.column === col ? 1 : 0.3,
                        fontSize: "10px"
                      }}>
                        {sortConfig.column === col && sortConfig.direction === 'asc' ? '▲' : '▼'}
                      </span>
                    </div>
                  </th>
                ))}
                <th style={{
                  padding: "16px",
                  textAlign: "center",
                  fontSize: "12px",
                  fontWeight: "600",
                  color: "#374151",
                  textTransform: "uppercase",
                  letterSpacing: "0.5px",
                  borderBottom: "1px solid #e5e7eb",
                  width: "100px"
                }}>
                  Actions
                </th>
              </tr>
            </thead>
            <tbody>
              {paginatedRows.map((row, rowIndex) => (
                <tr
                  key={row.id}
                  style={{
                    borderBottom: rowIndex < paginatedRows.length - 1 ? "1px solid #f3f4f6" : "none",
                    backgroundColor: String(row[columns[0]]).toUpperCase() === "TOTAL" ? "#fef3c7" : "white"
                  }}
                  onMouseEnter={(e) => {
                    if (String(row[columns[0]]).toUpperCase() !== "TOTAL") {
                      e.currentTarget.style.backgroundColor = "#f9fafb";
                    }
                  }}
                  onMouseLeave={(e) => {
                    if (String(row[columns[0]]).toUpperCase() !== "TOTAL") {
                      e.currentTarget.style.backgroundColor = "white";
                    }
                  }}
                >
                  {columns.map((col) => (
                    <td
                      key={col}
                      style={{
                        padding: "16px",
                        fontSize: "14px",
                        color: "#1f2937",
                        borderRight: "1px solid #f3f4f6"
                      }}
                    >
                      {editingCell.rowId === row.id && editingCell.column === col ? (
                        <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
                          <input
                            type="text"
                            value={editValue}
                            onChange={(e) => setEditValue(e.target.value)}
                            onKeyPress={(e) => {
                              if (e.key === 'Enter') handleSaveEdit();
                              if (e.key === 'Escape') handleCancelEdit();
                            }}
                            style={{
                              border: "1px solid #3b82f6",
                              borderRadius: "4px",
                              padding: "6px 8px",
                              fontSize: "14px",
                              outline: "none",
                              minWidth: "100px"
                            }}
                            autoFocus
                          />
                          <button
                            onClick={handleSaveEdit}
                            style={{
                              background: "none",
                              border: "none",
                              color: "#10b981",
                              cursor: "pointer",
                              fontSize: "16px"
                            }}
                            title="Save"
                          >
                            ✓
                          </button>
                          <button
                            onClick={handleCancelEdit}
                            style={{
                              background: "none",
                              border: "none",
                              color: "#ef4444",
                              cursor: "pointer",
                              fontSize: "16px"
                            }}
                            title="Cancel"
                          >
                            ✕
                          </button>
                        </div>
                      ) : (
                        <div
                          onClick={() => handleEdit(row.id, col, row[col])}
                          style={{
                            cursor: "pointer",
                            padding: "4px 8px",
                            borderRadius: "4px",
                            transition: "background-color 0.2s",
                            minHeight: "24px",
                            display: "flex",
                            alignItems: "center"
                          }}
                          onMouseEnter={(e) => e.target.style.backgroundColor = "#f3f4f6"}
                          onMouseLeave={(e) => e.target.style.backgroundColor = "transparent"}
                          title="Click to edit"
                        >
                          {formatCellValue(row[col], col)}
                        </div>
                      )}
                    </td>
                  ))}
                  <td style={{ 
                    padding: "16px", 
                    textAlign: "center",
                    borderLeft: "1px solid #f3f4f6"
                  }}>
                    <button
                      onClick={() => handleDelete(row.id)}
                      style={{
                        backgroundColor: deleteConfirm === row.id ? "#ef4444" : "#fef2f2",
                        color: deleteConfirm === row.id ? "white" : "#ef4444",
                        border: deleteConfirm === row.id ? "none" : "1px solid #fecaca",
                        padding: "8px 16px",
                        borderRadius: "6px",
                        fontSize: "12px",
                        fontWeight: "500",
                        cursor: "pointer",
                        transition: "all 0.2s"
                      }}
                      onMouseEnter={(e) => {
                        if (deleteConfirm !== row.id) {
                          e.target.style.backgroundColor = "#fee2e2";
                          e.target.style.borderColor = "#fca5a5";
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (deleteConfirm !== row.id) {
                          e.target.style.backgroundColor = "#fef2f2";
                          e.target.style.borderColor = "#fecaca";
                        }
                      }}
                    >
                      {deleteConfirm === row.id ? "Confirm Delete" : "Delete"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "16px 20px",
            borderTop: "1px solid #e5e7eb",
            backgroundColor: "#f9fafb"
          }}>
            <div style={{ fontSize: "14px", color: "#6b7280" }}>
              Showing {((currentPage - 1) * rowsPerPage) + 1} to {Math.min(currentPage * rowsPerPage, filteredAndSortedRows.length)} of {filteredAndSortedRows.length} records
            </div>
            <div style={{ display: "flex", gap: "8px", alignItems: "center" }}>
              <button
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
                style={{
                  padding: "8px 12px",
                  border: "1px solid #d1d5db",
                  borderRadius: "6px",
                  backgroundColor: currentPage === 1 ? "#f9fafb" : "white",
                  color: currentPage === 1 ? "#9ca3af" : "#374151",
                  cursor: currentPage === 1 ? "not-allowed" : "pointer",
                  fontSize: "14px"
                }}
              >
                Previous
              </button>
              
              <div style={{ display: "flex", gap: "4px" }}>
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNum;
                  if (totalPages <= 5) {
                    pageNum = i + 1;
                  } else if (currentPage <= 3) {
                    pageNum = i + 1;
                  } else if (currentPage >= totalPages - 2) {
                    pageNum = totalPages - 4 + i;
                  } else {
                    pageNum = currentPage - 2 + i;
                  }
                  
                  return (
                    <button
                      key={pageNum}
                      onClick={() => setCurrentPage(pageNum)}
                      style={{
                        padding: "8px 12px",
                        border: "1px solid #d1d5db",
                        borderRadius: "6px",
                        backgroundColor: currentPage === pageNum ? "#3b82f6" : "white",
                        color: currentPage === pageNum ? "white" : "#374151",
                        cursor: "pointer",
                        fontSize: "14px",
                        fontWeight: currentPage === pageNum ? "600" : "400"
                      }}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>
              
              <button
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                disabled={currentPage === totalPages}
                style={{
                  padding: "8px 12px",
                  border: "1px solid #d1d5db",
                  borderRadius: "6px",
                  backgroundColor: currentPage === totalPages ? "#f9fafb" : "white",
                  color: currentPage === totalPages ? "#9ca3af" : "#374151",
                  cursor: currentPage === totalPages ? "not-allowed" : "pointer",
                  fontSize: "14px"
                }}
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>

      {filteredAndSortedRows.length === 0 && !loading && (
        <div style={{
          textAlign: "center",
          padding: "60px 20px",
          color: "#6b7280",
          backgroundColor: "white",
          borderRadius: "12px",
          border: "1px solid #e5e7eb",
          marginTop: "20px"
        }}>
          <div style={{ fontSize: "48px", marginBottom: "16px", opacity: 0.5 }}>📭</div>
          <h3 style={{ fontSize: "18px", fontWeight: "600", margin: "0 0 8px 0" }}>No records found</h3>
          <p style={{ margin: 0, fontSize: "14px" }}>
            {searchTerm ? `No records match "${searchTerm}"` : "This collection is empty"}
          </p>
          {searchTerm && (
            <button
              onClick={() => setSearchTerm("")}
              style={{
                marginTop: "16px",
                padding: "8px 16px",
                backgroundColor: "#3b82f6",
                color: "white",
                border: "none",
                borderRadius: "6px",
                fontSize: "14px",
                cursor: "pointer"
              }}
            >
              Clear Search
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export default DataTable;