// src/components/Sidebar.jsx
import React, { useEffect, useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { db } from "../firebase";
import {
  collection,
  onSnapshot,
  deleteDoc,
  query,
  where,
  getDocs,
} from "firebase/firestore";

export default function Sidebar() {
  const [datasets, setDatasets] = useState([]);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // 🔄 Real-time listener for datasets
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "datasets"), (snapshot) => {
      const names = snapshot.docs
        .map((doc) => doc.data().name)
        .sort((a, b) => a.localeCompare(b));
      setDatasets(names);
    });

    return () => unsubscribe();
  }, []);

  // 🗑️ Delete dataset from Firestore
  const handleDeleteDataset = async (datasetName) => {
    const confirmed = window.confirm(
      `Are you sure you want to delete the dataset "${datasetName}"? This action cannot be undone.`
    );
    if (!confirmed) return;

    try {
      // Find dataset(s) with this name and delete them
      const q = query(collection(db, "datasets"), where("name", "==", datasetName));
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        alert("Dataset not found in the database.");
        return;
      }

      const deletePromises = snapshot.docs.map((doc) => deleteDoc(doc.ref));
      await Promise.all(deletePromises);

      alert(`✅ Dataset "${datasetName}" deleted successfully.`);
      // If the current page is viewing that dataset, redirect to dashboard
      if (location.pathname === `/dataset/${datasetName}`) {
        navigate("/dashboard");
      }
    } catch (error) {
      console.error("Error deleting dataset:", error);
      alert("❌ Failed to delete dataset. Check the console for details.");
    }
  };

  const handleLogout = () => {
    const confirmed = window.confirm("Are you sure you want to logout?");
    if (confirmed) {
      localStorage.removeItem("loggedIn");
      window.location.href = "/";
    }
  };

  const isActiveLink = (path) => location.pathname === path;

  const sidebarStyle = {
    width: isCollapsed ? "80px" : "280px",
    background: "linear-gradient(180deg, #667eea 0%, #764ba2 100%)",
    backdropFilter: "blur(16px)",
    color: "#fff",
    padding: isCollapsed ? "1rem 0.5rem" : "1.5rem",
    minHeight: "100vh",
    transition: "all 0.3s ease",
    borderRight: "1px solid rgba(255, 255, 255, 0.1)",
    boxShadow: "0 0 50px rgba(0, 0, 0, 0.1)",
    position: "relative",
    fontFamily:
      "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
  };

  const headerStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: "2rem",
    paddingBottom: "1rem",
    borderBottom: "1px solid rgba(255, 255, 255, 0.1)",
  };

  const logoStyle = {
    fontSize: isCollapsed ? "1.5rem" : "1.75rem",
    fontWeight: "bold",
    color: "white",
    display: "flex",
    alignItems: "center",
    gap: isCollapsed ? "0" : "0.5rem",
  };

  const toggleButtonStyle = {
    background: "rgba(255, 255, 255, 0.1)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    borderRadius: "0.5rem",
    color: "white",
    cursor: "pointer",
    padding: "0.5rem",
    fontSize: "1rem",
    transition: "all 0.2s ease",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  };

  const navStyle = { marginBottom: "2rem" };
  const navListStyle = { listStyle: "none", padding: 0, margin: 0 };
  const navItemStyle = { marginBottom: "0.5rem" };

  const linkStyle = (isActive) => ({
    color: "white",
    textDecoration: "none",
    display: "flex",
    alignItems: "center",
    gap: isCollapsed ? "0" : "0.75rem",
    padding: "0.875rem",
    borderRadius: "0.75rem",
    background: isActive ? "rgba(255, 255, 255, 0.2)" : "transparent",
    border: isActive
      ? "1px solid rgba(255, 255, 255, 0.3)"
      : "1px solid transparent",
    transition: "all 0.2s ease",
    fontSize: "0.95rem",
    fontWeight: isActive ? "600" : "500",
    position: "relative",
    overflow: "hidden",
    justifyContent: isCollapsed ? "center" : "flex-start",
  });

  const sectionHeaderStyle = {
    color: "rgba(255, 255, 255, 0.7)",
    fontSize: "0.75rem",
    fontWeight: "600",
    textTransform: "uppercase",
    letterSpacing: "0.05em",
    margin: "1.5rem 0 0.75rem 0",
    display: isCollapsed ? "none" : "block",
  };

  const datasetItemStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: isCollapsed ? "center" : "space-between",
    padding: "0.5rem 0.875rem",
    borderRadius: "0.5rem",
    transition: "background 0.2s ease",
  };

  const datasetLinkStyle = (isActive) => ({
    ...linkStyle(isActive),
    paddingLeft: isCollapsed ? "0.875rem" : "2rem",
    fontSize: "0.875rem",
    opacity: 0.9,
    flex: 1,
  });

  const deleteButtonStyle = {
    background: "transparent",
    border: "none",
    color: "rgba(255, 255, 255, 0.6)",
    cursor: "pointer",
    marginLeft: "0.5rem",
    fontSize: "0.9rem",
    transition: "color 0.2s ease",
  };

  const logoutButtonStyle = {
    marginTop: "2rem",
    background: "linear-gradient(135deg, #ef4444, #dc2626)",
    border: "none",
    padding: isCollapsed ? "0.875rem" : "0.875rem 1rem",
    color: "#fff",
    cursor: "pointer",
    width: "100%",
    borderRadius: "0.75rem",
    fontSize: "0.95rem",
    fontWeight: "600",
    display: "flex",
    alignItems: "center",
    justifyContent: isCollapsed ? "center" : "flex-start",
    gap: isCollapsed ? "0" : "0.5rem",
    transition: "all 0.2s ease",
    boxShadow: "0 4px 15px rgba(239, 68, 68, 0.3)",
  };

  return (
    <aside style={sidebarStyle}>
      {/* Header */}
      <div style={headerStyle}>
        <div style={logoStyle}>
          <span>📊</span>
          {!isCollapsed && <span>Dashboard</span>}
        </div>
        <button
          onClick={() => setIsCollapsed(!isCollapsed)}
          style={toggleButtonStyle}
          onMouseEnter={(e) => {
            e.target.style.background = "rgba(255, 255, 255, 0.2)";
          }}
          onMouseLeave={(e) => {
            e.target.style.background = "rgba(255, 255, 255, 0.1)";
          }}
        >
          {isCollapsed ? "→" : "←"}
        </button>
      </div>

      {/* Main Navigation */}
      <nav style={navStyle}>
        <ul style={navListStyle}>
          <li style={navItemStyle}>
            <Link to="/dashboard" style={linkStyle(isActiveLink("/dashboard"))}>
              <span>🏠</span>
              {!isCollapsed && <span>Home</span>}
            </Link>
          </li>

          <li style={navItemStyle}>
            <Link to="/import" style={linkStyle(isActiveLink("/import"))}>
              <span>📥</span>
              {!isCollapsed && <span>Import CSV</span>}
            </Link>
          </li>
        </ul>
      </nav>

      {/* Datasets Section */}
      <div>
        <div style={sectionHeaderStyle}>📂 Datasets</div>
        <ul style={navListStyle}>
          {datasets.length === 0 && !isCollapsed && (
            <li
              style={{
                color: "rgba(255, 255, 255, 0.5)",
                fontSize: "0.875rem",
                padding: "0.5rem 0.875rem",
                fontStyle: "italic",
              }}
            >
              No datasets yet
            </li>
          )}
          {datasets.map((ds, i) => (
            <li key={i} style={datasetItemStyle}>
              <Link
                to={`/dataset/${ds}`}
                style={datasetLinkStyle(isActiveLink(`/dataset/${ds}`))}
              >
                <span>📄</span>
                {!isCollapsed && (
                  <span
                    style={{
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                      maxWidth: "140px",
                    }}
                    title={ds}
                  >
                    {ds}
                  </span>
                )}
              </Link>
              {!isCollapsed && (
                <button
                  onClick={() => handleDeleteDataset(ds)}
                  style={deleteButtonStyle}
                  title="Delete dataset"
                  onMouseEnter={(e) =>
                    (e.target.style.color = "rgba(255, 100, 100, 0.9)")
                  }
                  onMouseLeave={(e) =>
                    (e.target.style.color = "rgba(255, 255, 255, 0.6)")
                  }
                >
                  🗑️
                </button>
              )}
            </li>
          ))}
        </ul>
      </div>

      {/* Datasets Count */}
      {datasets.length > 0 && !isCollapsed && (
        <div
          style={{
            marginTop: "1rem",
            padding: "0.75rem",
            background: "rgba(255, 255, 255, 0.1)",
            borderRadius: "0.75rem",
            border: "1px solid rgba(255, 255, 255, 0.2)",
          }}
        >
          <div
            style={{
              fontSize: "0.875rem",
              color: "rgba(255, 255, 255, 0.8)",
              marginBottom: "0.25rem",
            }}
          >
            Total Datasets
          </div>
          <div style={{ fontSize: "1.5rem", fontWeight: "bold", color: "white" }}>
            {datasets.length}
          </div>
        </div>
      )}

      {/* Logout Button */}
      <button
        onClick={handleLogout}
        style={logoutButtonStyle}
        onMouseEnter={(e) => {
          e.target.style.background = "linear-gradient(135deg, #dc2626, #b91c1c)";
          e.target.style.transform = "translateY(-2px)";
        }}
        onMouseLeave={(e) => {
          e.target.style.background = "linear-gradient(135deg, #ef4444, #dc2626)";
          e.target.style.transform = "translateY(0)";
        }}
      >
        <span>🚪</span>
        {!isCollapsed && <span>Logout</span>}
      </button>

      <style>{`
        @media (max-width: 768px) {
          aside {
            position: fixed;
            z-index: 1000;
            height: 100vh;
          }
        }
      `}</style>
    </aside>
  );
}
