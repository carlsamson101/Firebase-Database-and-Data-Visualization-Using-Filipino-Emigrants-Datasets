import { processAggregation } from './chartHelpers';

export const processChartData = (filteredData, selectedChart, xAxis, yAxis, groupBy, columnTypes, headers, aggregationType) => {
  if (!filteredData.length || !xAxis || !yAxis) return [];
  
  switch (selectedChart) {
    case 'comparison':
      return processComparisonData(filteredData, xAxis, yAxis, aggregationType);
    
    case 'composition':
      return processCompositionData(filteredData, groupBy, yAxis, aggregationType);
    
    case 'trends':
      return processTrendsData(filteredData, xAxis, yAxis, groupBy, aggregationType);
    
    case 'distribution':
      return processDistributionData(filteredData, xAxis, yAxis, groupBy);
    
    case 'relationships':
      return processRelationshipData(filteredData, xAxis, yAxis, groupBy, headers, columnTypes);
    
    case 'heatmap':
      return processHeatmapData(filteredData, xAxis, yAxis, groupBy, aggregationType);
    
    case 'geographic':
      return processGeographicData(filteredData, yAxis, groupBy, headers, aggregationType);
    
    default:
      return filteredData.slice(0, 100);
  }
};

const processComparisonData = (filteredData, xAxis, yAxis, aggregationType) => {
  const grouped = {};
  filteredData.forEach(item => {
    const key = String(item[xAxis] || 'Unknown');
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(item[yAxis]);
  });
  
  return Object.entries(grouped)
    .map(([key, values]) => ({ 
      [xAxis]: key, 
      [yAxis]: processAggregation(values, aggregationType),
      count: values.length,
      _metadata: { originalValues: values }
    }))
    .sort((a, b) => {
      const aVal = a[xAxis];
      const bVal = b[xAxis];
      if (!isNaN(Number(aVal)) && !isNaN(Number(bVal))) {
        return Number(aVal) - Number(bVal);
      }
      return String(aVal).localeCompare(String(bVal));
    });
};

const processCompositionData = (filteredData, groupBy, yAxis, aggregationType) => {
  const pieGrouped = {};
  filteredData.forEach(item => {
    const key = String(item[groupBy] || 'Unknown');
    if (!pieGrouped[key]) pieGrouped[key] = [];
    pieGrouped[key].push(item[yAxis]);
  });
  
  return Object.entries(pieGrouped)
    .map(([name, values]) => ({ 
      name, 
      value: processAggregation(values, aggregationType),
      count: values.length,
      percentage: 0
    }))
    .sort((a, b) => b.value - a.value)
    .map((item, index, array) => {
      const total = array.reduce((sum, i) => sum + i.value, 0);
      return { ...item, percentage: total > 0 ? (item.value / total * 100) : 0 };
    });
};

const processTrendsData = (filteredData, xAxis, yAxis, groupBy, aggregationType) => {
  if (!groupBy || groupBy === xAxis) {
    const trendGrouped = {};
    filteredData.forEach(item => {
      const xVal = String(item[xAxis]);
      if (!trendGrouped[xVal]) trendGrouped[xVal] = [];
      trendGrouped[xVal].push(item[yAxis]);
    });
    
    return Object.entries(trendGrouped)
      .map(([key, values]) => ({
        [xAxis]: key,
        [yAxis]: processAggregation(values, aggregationType),
        count: values.length
      }))
      .sort((a, b) => sortValues(a[xAxis], b[xAxis]));
  } else {
    const multiTrendGrouped = {};
    filteredData.forEach(item => {
      const xVal = String(item[xAxis]);
      const groupVal = String(item[groupBy]);
      if (!multiTrendGrouped[xVal]) multiTrendGrouped[xVal] = { [xAxis]: xVal };
      if (!multiTrendGrouped[xVal][groupVal]) multiTrendGrouped[xVal][groupVal] = [];
      multiTrendGrouped[xVal][groupVal].push(item[yAxis]);
    });
    
    return Object.values(multiTrendGrouped)
      .map(group => {
        const result = { [xAxis]: group[xAxis] };
        Object.keys(group).forEach(key => {
          if (key !== xAxis) {
            result[key] = processAggregation(group[key], aggregationType);
          }
        });
        return result;
      })
      .sort((a, b) => sortValues(a[xAxis], b[xAxis]));
  }
};

const processDistributionData = (filteredData, xAxis, yAxis, groupBy) => {
  return filteredData
    .map(item => ({
      [xAxis]: item[xAxis],
      [yAxis]: Number(item[yAxis]) || 0,
      category: item[groupBy],
      density: 1
    }))
    .sort((a, b) => sortValues(a[xAxis], b[xAxis]));
};

const processRelationshipData = (filteredData, xAxis, yAxis, groupBy, headers, columnTypes) => {
  const numericCols = headers.filter(h => columnTypes[h] === 'numeric');
  if (numericCols.length < 2) {
    return filteredData.map((item, index) => ({
      x: index,
      y: Number(item[yAxis]) || 0,
      category: item[groupBy] || 'Data',
      name: `${item[Object.keys(item)[1]] || 'Item'} ${index + 1}`,
      size: Math.abs(Number(item[yAxis]) || 0) + 1
    }));
  }
  
  return filteredData.map(item => ({
    x: Number(item[xAxis]) || 0,
    y: Number(item[yAxis]) || 0,
    category: item[groupBy] || 'Data',
    name: `${item[Object.keys(item).find(k => k !== 'id' && k !== xAxis && k !== yAxis)] || 'Item'}`,
    size: Math.abs(Number(item[yAxis]) || 0) / 10 + 5
  }));
};

const processHeatmapData = (filteredData, xAxis, yAxis, groupBy, aggregationType) => {
  const heatmapData = {};
  filteredData.forEach(item => {
    const xVal = String(item[xAxis] || 'Unknown');
    const yVal = String(item[groupBy] || 'Unknown');
    const key = `${xVal}-${yVal}`;
    if (!heatmapData[key]) {
      heatmapData[key] = { x: xVal, y: yVal, values: [] };
    }
    heatmapData[key].values.push(Number(item[yAxis]) || 0);
  });
  
  return Object.values(heatmapData).map(item => ({
    x: item.x,
    y: item.y,
    value: processAggregation(item.values, aggregationType),
    count: item.values.length
  }));
};

const processGeographicData = (filteredData, yAxis, groupBy, headers, aggregationType) => {
  const geoColumn = headers.find(h => 
    h.toLowerCase().includes('region') || 
    h.toLowerCase().includes('location') || 
    h.toLowerCase().includes('area') ||
    h.toLowerCase().includes('city') ||
    h.toLowerCase().includes('province') ||
    h.toLowerCase().includes('country')
  ) || groupBy;
  
  const regionGrouped = {};
  filteredData.forEach(item => {
    const region = String(item[geoColumn] || 'Unknown');
    if (!regionGrouped[region]) regionGrouped[region] = [];
    regionGrouped[region].push(item[yAxis]);
  });
  
  return Object.entries(regionGrouped)
    .map(([region, values]) => ({ 
      region, 
      value: processAggregation(values, aggregationType),
      count: values.length
    }))
    .sort((a, b) => b.value - a.value);
};

const sortValues = (aVal, bVal) => {
  if (!isNaN(Number(aVal)) && !isNaN(Number(bVal))) {
    return Number(aVal) - Number(bVal);
  }
  return String(aVal).localeCompare(String(bVal));
};