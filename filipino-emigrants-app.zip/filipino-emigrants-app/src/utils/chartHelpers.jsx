// Chart utility functions
export const calculateCorrelation = (data, col1, col2) => {
  const pairs = data
    .map(row => [Number(row[col1]), Number(row[col2])])
    .filter(([a, b]) => !isNaN(a) && !isNaN(b));
  
  if (pairs.length < 2) return 0;
  
  const mean1 = pairs.reduce((sum, [a]) => sum + a, 0) / pairs.length;
  const mean2 = pairs.reduce((sum, [, b]) => sum + b, 0) / pairs.length;
  
  const numerator = pairs.reduce((sum, [a, b]) => sum + (a - mean1) * (b - mean2), 0);
  const denominator = Math.sqrt(
    pairs.reduce((sum, [a]) => sum + (a - mean1) ** 2, 0) *
    pairs.reduce((sum, [, b]) => sum + (b - mean2) ** 2, 0)
  );
  
  return denominator === 0 ? 0 : numerator / denominator;
};

export const calculateTrend = (timeSeriesData) => {
  const n = timeSeriesData.length;
  const sumX = timeSeriesData.reduce((sum, d, i) => sum + i, 0);
  const sumY = timeSeriesData.reduce((sum, d) => sum + d.value, 0);
  const sumXY = timeSeriesData.reduce((sum, d, i) => sum + i * d.value, 0);
  const sumX2 = timeSeriesData.reduce((sum, d, i) => sum + i * i, 0);
  
  const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
  const intercept = (sumY - slope * sumX) / n;
  
  return { 
    slope, 
    intercept, 
    direction: slope > 0 ? 'increasing' : slope < 0 ? 'decreasing' : 'stable' 
  };
};

export const detectOutliers = (data, cols) => {
  const outlierData = [];
  const numericCols = cols.filter(col => {
    return data.some(row => !isNaN(Number(row[col])) && row[col] !== '' && row[col] !== null);
  });

  numericCols.forEach(col => {
    const values = data.map(row => Number(row[col])).filter(val => !isNaN(val)).sort((a, b) => a - b);
    if (values.length > 4) {
      const q1 = values[Math.floor(values.length * 0.25)];
      const q3 = values[Math.floor(values.length * 0.75)];
      const iqr = q3 - q1;
      const lowerBound = q1 - 1.5 * iqr;
      const upperBound = q3 + 1.5 * iqr;
      
      data.forEach((row, index) => {
        const value = Number(row[col]);
        if (!isNaN(value) && (value < lowerBound || value > upperBound)) {
          outlierData.push({ 
            row: index, 
            column: col, 
            value, 
            bound: value < lowerBound ? 'lower' : 'upper' 
          });
        }
      });
    }
  });
  return outlierData;
};

export const processAggregation = (values, type) => {
  const numericValues = values.filter(v => !isNaN(Number(v))).map(Number);
  if (numericValues.length === 0) return 0;
  
  switch (type) {
    case 'sum': return numericValues.reduce((a, b) => a + b, 0);
    case 'average': return numericValues.reduce((a, b) => a + b, 0) / numericValues.length;
    case 'count': return values.length;
    case 'min': return Math.min(...numericValues);
    case 'max': return Math.max(...numericValues);
    default: return numericValues.reduce((a, b) => a + b, 0);
  }
};

export const getColorScheme = (theme) => {
  switch (theme) {
    case 'dark':
      return ['#1f2937', '#374151', '#4b5563', '#6b7280', '#9ca3af', '#d1d5db'];
    case 'colorful':
      return ['#ff6b6b', '#4ecdc4', '#45b7d1', '#f9ca24', '#f0932b', '#eb4d4b', '#6c5ce7', '#a29bfe'];
    case 'professional':
      return ['#2563eb', '#7c3aed', '#dc2626', '#059669', '#d97706', '#4338ca'];
    default:
      return ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#34495e', '#e67e22'];
  }
};

export const detectColumnTypes = (records, headers) => {
  const types = {};
  headers.forEach(header => {
    const sampleValues = records.slice(0, 50).map(r => r[header]).filter(v => v != null && v !== '');
    const numericCount = sampleValues.filter(v => !isNaN(Number(v))).length;
    const dateCount = sampleValues.filter(v => !isNaN(Date.parse(v))).length;
    
    if (dateCount > sampleValues.length * 0.7) {
      types[header] = 'date';
    } else if (numericCount > sampleValues.length * 0.8) {
      types[header] = 'numeric';
    } else {
      types[header] = 'categorical';
    }
  });
  return types;
};