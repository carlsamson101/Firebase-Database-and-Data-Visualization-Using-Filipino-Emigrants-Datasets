import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyADmEZQ7778lFQy-dRyPK99qwiFSaf7IHY",
  authDomain: "carlsamson-1017c.firebaseapp.com",
  projectId: "carlsamson-1017c",
  storageBucket: "carlsamson-1017c.firebasestorage.app",
  messagingSenderId: "609984004250",
  appId: "1:609984004250:web:c43b43c067bfce9b619f23",
  measurementId: "G-4LWJH5KHV6"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
