// src/pages/ImportCSV.jsx
import React, { useState } from "react";
import Papa from "papaparse";
import { db } from "../firebase";
import Layout from "../components/Layout"; // ✅ use Layout instead of Sidebar
import { collection, addDoc, query, where, getDocs } from "firebase/firestore";


export default function ImportCSV() {
  const [csvData, setCsvData] = useState([]);
  const [headers, setHeaders] = useState([]);
  const [collectionName, setCollectionName] = useState("");
  const [uploading, setUploading] = useState(false);
  const [dragActive, setDragActive] = useState(false);

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    processFile(file);
  };

  const processFile = (file) => {
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        setCsvData(results.data);
        setHeaders(results.meta.fields);
      },
    });
  };

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type === "text/csv" || file.name.endsWith('.csv')) {
        processFile(file);
      } else {
        alert("Please upload a CSV file only!");
      }
    }
  };

  const handleUpload = async () => {
  if (!collectionName.trim()) {
    alert("Please enter a collection name!");
    return;
  }
  if (csvData.length === 0) {
    alert("No data to upload!");
    return;
  }

  setUploading(true);
  try {
    // Upload rows to selected collection
    for (let row of csvData) {
      await addDoc(collection(db, collectionName), row);
    }

    // Check if dataset already exists
    const q = query(
      collection(db, "datasets"),
      where("name", "==", collectionName)
    );
    const existing = await getDocs(q);

    if (existing.empty) {
      await addDoc(collection(db, "datasets"), { name: collectionName });
    }

    alert(`✅ Successfully uploaded ${csvData.length} records to "${collectionName}"`);
    setCsvData([]);
    setHeaders([]);
    setCollectionName("");
  } catch (error) {
    console.error("Upload error:", error);
    alert("❌ Failed to upload data. Check console for details.");
  }
  setUploading(false);
};
  const containerStyle = {
    flex: 1,
    padding: "2rem",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    minHeight: "100vh",
    fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif"
  };

  const cardStyle = {
    background: "rgba(255, 255, 255, 0.1)",
    backdropFilter: "blur(16px)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    borderRadius: "1.5rem",
    padding: "2rem",
    marginBottom: "2rem",
    boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.25)"
  };

  const titleStyle = {
    fontSize: "2rem",
    fontWeight: "bold",
    color: "white",
    marginBottom: "0.5rem",
    display: "flex",
    alignItems: "center",
    gap: "0.5rem"
  };

  const subtitleStyle = {
    color: "rgba(255, 255, 255, 0.8)",
    fontSize: "1rem",
    marginBottom: "2rem"
  };

  const dropZoneStyle = {
    border: dragActive 
      ? "3px dashed rgba(139, 92, 246, 0.8)" 
      : "3px dashed rgba(255, 255, 255, 0.3)",
    borderRadius: "1rem",
    padding: "3rem",
    textAlign: "center",
    background: dragActive 
      ? "rgba(139, 92, 246, 0.1)" 
      : "rgba(255, 255, 255, 0.05)",
    transition: "all 0.3s ease",
    cursor: "pointer",
    marginBottom: "2rem"
  };

  const fileInputStyle = {
    display: "none"
  };

  const dropTextStyle = {
    color: "white",
    fontSize: "1.125rem",
    fontWeight: "500",
    marginBottom: "1rem"
  };

  const dropSubtextStyle = {
    color: "rgba(255, 255, 255, 0.7)",
    fontSize: "0.875rem"
  };

  const previewCardStyle = {
    ...cardStyle,
    maxHeight: "500px",
    overflowY: "auto"
  };

  const tableStyle = {
    width: "100%",
    borderCollapse: "collapse",
    marginBottom: "1rem",
    background: "rgba(255, 255, 255, 0.05)",
    borderRadius: "0.75rem",
    overflow: "hidden"
  };

  const thStyle = {
    background: "rgba(139, 92, 246, 0.3)",
    color: "white",
    padding: "1rem",
    textAlign: "left",
    fontWeight: "600",
    fontSize: "0.875rem",
    borderBottom: "1px solid rgba(255, 255, 255, 0.1)"
  };

  const tdStyle = {
    padding: "0.75rem 1rem",
    color: "rgba(255, 255, 255, 0.9)",
    fontSize: "0.875rem",
    borderBottom: "1px solid rgba(255, 255, 255, 0.05)"
  };

  const inputStyle = {
    width: "100%",
    padding: "0.75rem 1rem",
    background: "rgba(255, 255, 255, 0.1)",
    backdropFilter: "blur(8px)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    borderRadius: "0.75rem",
    color: "white",
    fontSize: "1rem",
    outline: "none",
    transition: "all 0.2s ease",
    boxSizing: "border-box",
    marginBottom: "1rem"
  };

  const buttonStyle = {
    padding: "0.75rem 1.5rem",
    background: uploading 
      ? "rgba(139, 92, 246, 0.5)" 
      : "linear-gradient(135deg, #8b5cf6, #ec4899)",
    color: "white",
    fontWeight: "600",
    border: "none",
    borderRadius: "0.75rem",
    cursor: uploading ? "not-allowed" : "pointer",
    fontSize: "1rem",
    display: "inline-flex",
    alignItems: "center",
    gap: "0.5rem",
    transition: "all 0.2s ease",
    boxShadow: "0 10px 25px rgba(139, 92, 246, 0.3)"
  };

  const statsStyle = {
    display: "flex",
    gap: "1rem",
    marginBottom: "1.5rem"
  };

  const statCardStyle = {
    background: "rgba(255, 255, 255, 0.1)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    borderRadius: "0.75rem",
    padding: "1rem",
    textAlign: "center",
    flex: 1
  };

  const statNumberStyle = {
    fontSize: "1.5rem",
    fontWeight: "bold",
    color: "white",
    display: "block"
  };

  const statLabelStyle = {
    fontSize: "0.75rem",
    color: "rgba(255, 255, 255, 0.7)",
    marginTop: "0.25rem"
  };

  return (
    <Layout>
      <main style={containerStyle}>
        {/* Header Card */}
        <div style={cardStyle}>
          <h1 style={titleStyle}>
            <span>📤</span>
            Import CSV to Firebase
          </h1>
          <p style={subtitleStyle}>
            Upload and process your CSV files with ease. Drag and drop or click to select a file.
          </p>

          {/* File Drop Zone */}
          <div
            style={dropZoneStyle}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => document.getElementById('fileInput').click()}
          >
            <input
              id="fileInput"
              type="file"
              accept=".csv"
              onChange={handleFileChange}
              style={fileInputStyle}
            />
            <div style={dropTextStyle}>
              {dragActive ? "📂 Drop your CSV file here!" : "📁 Click to select or drag & drop CSV file"}
            </div>
            <p style={dropSubtextStyle}>
              Supports CSV files up to 10MB
            </p>
          </div>
        </div>

        {/* Data Preview */}
        {csvData.length > 0 && (
          <div style={previewCardStyle}>
            <h2 style={{...titleStyle, fontSize: "1.5rem", marginBottom: "1.5rem"}}>
              <span>📋</span>
              Data Preview
            </h2>

            {/* Statistics */}
            <div style={statsStyle}>
              <div style={statCardStyle}>
                <span style={statNumberStyle}>{csvData.length}</span>
                <div style={statLabelStyle}>Total Rows</div>
              </div>
              <div style={statCardStyle}>
                <span style={statNumberStyle}>{headers.length}</span>
                <div style={statLabelStyle}>Columns</div>
              </div>
              <div style={statCardStyle}>
                <span style={statNumberStyle}>CSV</span>
                <div style={statLabelStyle}>File Type</div>
              </div>
            </div>

            {/* Preview Table */}
            <div style={{overflowX: "auto", marginBottom: "1.5rem"}}>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    {headers.map((header, i) => (
                      <th key={i} style={thStyle}>{header}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {csvData.slice(0, 10).map((row, i) => (
                    <tr key={i}>
                      {headers.map((h, j) => (
                        <td key={j} style={tdStyle}>{row[h] || "-"}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            
            <p style={{color: "rgba(255, 255, 255, 0.7)", fontSize: "0.875rem", marginBottom: "1.5rem"}}>
              📝 Showing first 10 rows of {csvData.length} total records
            </p>

            {/* Collection Name Input */}
            <div style={{marginBottom: "1.5rem"}}>
              <label style={{color: "white", fontSize: "0.875rem", fontWeight: "500", marginBottom: "0.5rem", display: "block"}}>
                🗃️ Firebase Collection Name:
              </label>
              <input
                type="text"
                placeholder="Enter collection name (e.g., users, products, etc.)"
                value={collectionName}
                onChange={(e) => setCollectionName(e.target.value)}
                style={inputStyle}
                onFocus={(e) => e.target.style.borderColor = "rgba(139, 92, 246, 0.5)"}
                onBlur={(e) => e.target.style.borderColor = "rgba(255, 255, 255, 0.2)"}
              />
            </div>

            {/* Upload Button */}
            <button
              onClick={handleUpload}
              disabled={uploading}
              style={buttonStyle}
              onMouseEnter={(e) => {
                if (!uploading) {
                  e.target.style.transform = "scale(1.02)";
                  e.target.style.background = "linear-gradient(135deg, #7c3aed, #db2777)";
                }
              }}
              onMouseLeave={(e) => {
                if (!uploading) {
                  e.target.style.transform = "scale(1)";
                  e.target.style.background = "linear-gradient(135deg, #8b5cf6, #ec4899)";
                }
              }}
            >
              {uploading ? (
                <>
                  <div style={{
                    width: "1rem",
                    height: "1rem",
                    border: "2px solid white",
                    borderTop: "2px solid transparent",
                    borderRadius: "50%",
                    animation: "spin 1s linear infinite"
                  }}></div>
                  <span>Uploading to Firebase...</span>
                </>
              ) : (
                <>
                  <span>🚀</span>
                  <span>Upload to Firebase</span>
                </>
              )}
            </button>
          </div>
        )}

        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
          input::placeholder {
            color: rgba(255, 255, 255, 0.6);
          }
          input:focus::placeholder {
            color: rgba(255, 255, 255, 0.4);
          }
        `}</style>
      </main>
    </Layout>
  );
}