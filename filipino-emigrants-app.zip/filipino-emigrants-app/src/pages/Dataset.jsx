import React, { useEffect, useState, useMemo } from "react";
import { useParams } from "react-router-dom";
import { db } from "../firebase";
import { collection, getDocs } from "firebase/firestore";
import Sidebar from "../components/Sidebar";
import DataTable from "../components/DataTable";
import { 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  CartesianGrid,
  Legend, 
  ScatterChart,
  Scatter,
  AreaChart,
  Area
} from "recharts";

export default function Dataset() {
  const { name } = useParams();
  const [records, setRecords] = useState([]);
  const [headers, setHeaders] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Chart configuration
  const [chartType, setChartType] = useState('bar');
  const [xAxis, setXAxis] = useState('');
  const [yAxis, setYAxis] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const colRef = collection(db, name);
        const snapshot = await getDocs(colRef);
        let data = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));

        if (data.length > 0) {
          const cols = Object.keys(data[0]).filter((h) => h !== "id");
          setHeaders(cols);
          
          // Set default axes - prefer date/year for x-axis, numeric for y-axis
          const dateCol = cols.find(c => c.toLowerCase().includes('year') || c.toLowerCase().includes('date'));
          const numericCols = cols.filter(col => {
            return data.some(row => !isNaN(Number(row[col])) && row[col] !== '' && row[col] !== null);
          });
          
          setXAxis(dateCol || cols[0]);
          setYAxis(numericCols[0] || cols[1]);
        }

        setRecords(data);
      } catch (error) {
        console.error("Error fetching data:", error);
      }
      setLoading(false);
    };

    if (name) {
      fetchData();
    }
  }, [name]);

 // Process all data for charts
const chartData = useMemo(() => {
  if (!records.length || !xAxis || !yAxis) return [];
  
  console.log("Chart Data Debug:", { 
    totalRecords: records.length, 
    xAxis, 
    yAxis,
    sampleData: records.slice(0, 3)
  });
  
  // Filter out total/summary rows
  const cleanData = records.filter(record => {
    const xValue = String(record[xAxis] || '').toLowerCase().trim();
    const excludeTerms = ['total', 'sum', 'average', 'avg', 'grand total', 'subtotal'];
    return !excludeTerms.some(term => xValue === term || xValue.includes(term));
  });
  
  console.log("After filtering totals:", cleanData.length);
  
  if (chartType === 'pie') {
    const grouped = {};
    cleanData.forEach(item => {
      const key = String(item[xAxis] || 'Unknown');
      const value = String(item[yAxis] || '0').replace(/["\s,]/g, '');
      grouped[key] = (grouped[key] || 0) + (Number(value) || 0);
    });
    
    return Object.entries(grouped)
      .map(([name, value]) => ({ name, value }))
      .filter(item => item.value > 0)
      .sort((a, b) => b.value - a.value);
  }
  
  if (chartType === 'scatter') {
    return cleanData.map((item, index) => {
      const xVal = String(item[xAxis] || '').replace(/["\s,]/g, '');
      const yVal = String(item[yAxis] || '').replace(/["\s,]/g, '');
      return {
        x: Number(xVal) || index,
        y: Number(yVal) || 0,
        name: String(item[Object.keys(item)[1]] || `Point ${index + 1}`)
      };
    }).filter(item => !isNaN(item.y) && item.y !== 0);
  }
  
  // For bar, line, and area charts - SHOW INDIVIDUAL ROWS or GROUP
  // Check if X-axis values are unique (no grouping needed)
  const xValues = cleanData.map(item => String(item[xAxis] || ''));
  const uniqueXValues = new Set(xValues);
  const needsGrouping = xValues.length !== uniqueXValues.size;
  
  console.log("Needs grouping?", needsGrouping, "Unique:", uniqueXValues.size, "Total:", xValues.length);
  
  if (!needsGrouping) {
    // No duplicates - show each row as-is
    return cleanData.map(item => {
      const yVal = String(item[yAxis] || '0').replace(/["\s,]/g, '');
      return {
        [xAxis]: String(item[xAxis] || 'Unknown'),
        [yAxis]: Number(yVal) || 0
      };
    }).filter(item => item[yAxis] > 0)
      .sort((a, b) => {
        const aVal = a[xAxis];
        const bVal = b[xAxis];
        // Try numeric sort first
        if (!isNaN(Number(aVal)) && !isNaN(Number(bVal))) {
          return Number(aVal) - Number(bVal);
        }
        return String(aVal).localeCompare(String(bVal));
      });
  }
  
  // Has duplicates - group and sum
  const grouped = {};
  cleanData.forEach(item => {
    const key = String(item[xAxis] || 'Unknown');
    const yVal = String(item[yAxis] || '0').replace(/["\s,]/g, '');
    const numValue = Number(yVal) || 0;
    
    if (!grouped[key]) {
      grouped[key] = { sum: 0, count: 0, values: [] };
    }
    grouped[key].sum += numValue;
    grouped[key].count += 1;
    grouped[key].values.push(numValue);
  });
  
  return Object.entries(grouped)
    .map(([key, data]) => ({
      [xAxis]: key,
      [yAxis]: data.sum, // Use sum for now
      count: data.count,
      average: data.sum / data.count
    }))
    .filter(item => item[yAxis] > 0)
    .sort((a, b) => {
      const aVal = a[xAxis];
      const bVal = b[xAxis];
      if (!isNaN(Number(aVal)) && !isNaN(Number(bVal))) {
        return Number(aVal) - Number(bVal);
      }
      return String(aVal).localeCompare(String(bVal));
    });
}, [records, chartType, xAxis, yAxis]);

  // Detect column types
  const getColumnType = (header) => {
    const sample = records.slice(0, 10);
    const numericCount = sample.filter(r => !isNaN(Number(r[header])) && r[header] !== '').length;
    const dateCount = sample.filter(r => !isNaN(Date.parse(r[header]))).length;
    
    if (dateCount > sample.length * 0.7) return 'date';
    if (numericCount > sample.length * 0.7) return 'numeric';
    return 'categorical';
  };

  const colors = ['#3498db', '#e74c3c', '#2ecc71', '#f39c12', '#9b59b6', '#1abc9c', '#34495e', '#e67e22'];

  const renderChart = () => {
    if (!chartData.length) {
      return (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: "4rem 0", color: "#7f8c8d" }}>
          <div style={{ fontSize: "64px", marginBottom: "1rem" }}>📊</div>
          <p style={{ fontSize: "18px", marginBottom: "0.5rem" }}>No data to display</p>
          <p style={{ fontSize: "14px" }}>Please select valid columns for X and Y axes</p>
        </div>
      );
    }

    const commonProps = {
      width: "100%",
      height: 400,
      margin: { top: 20, right: 30, left: 20, bottom: 80 }
    };

    switch (chartType) {
      case 'bar':
        return (
          <ResponsiveContainer {...commonProps}>
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis 
                dataKey={xAxis} 
                angle={chartData.length > 8 ? -45 : 0}
                textAnchor={chartData.length > 8 ? 'end' : 'middle'}
                height={chartData.length > 8 ? 100 : 60}
                fontSize={12}
              />
              <YAxis fontSize={12} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc', borderRadius: '8px' }}
                formatter={(value, name) => [value.toLocaleString(), yAxis]}
              />
              <Bar 
                dataKey={yAxis} 
                fill={colors[0]} 
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        );
      
      case 'line':
        return (
          <ResponsiveContainer {...commonProps}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey={xAxis} fontSize={12} />
              <YAxis fontSize={12} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc', borderRadius: '8px' }}
              />
              <Line 
                type="monotone" 
                dataKey={yAxis} 
                stroke={colors[0]} 
                strokeWidth={3}
                dot={{ r: 5, fill: colors[0] }}
              />
            </LineChart>
          </ResponsiveContainer>
        );
      
      case 'area':
        return (
          <ResponsiveContainer {...commonProps}>
            <AreaChart data={chartData}>
              <defs>
                <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={colors[0]} stopOpacity={0.8}/>
                  <stop offset="95%" stopColor={colors[0]} stopOpacity={0.2}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey={xAxis} fontSize={12} />
              <YAxis fontSize={12} />
              <Tooltip 
                contentStyle={{ backgroundColor: 'white', border: '1px solid #ccc', borderRadius: '8px' }}
              />
              <Area 
                type="monotone" 
                dataKey={yAxis} 
                stroke={colors[0]} 
                strokeWidth={2}
                fill="url(#colorGradient)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        );
      
      case 'scatter':
        return (
          <ResponsiveContainer {...commonProps}>
            <ScatterChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="x" name={xAxis} fontSize={12} />
              <YAxis dataKey="y" name={yAxis} fontSize={12} />
              <Tooltip 
                cursor={{ strokeDasharray: '3 3' }}
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload;
                    return (
                      <div style={{ background: "#fff", padding: "12px", border: "1px solid #ccc", borderRadius: "8px", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>
                        <p style={{ fontWeight: "600", marginBottom: "4px" }}>{data.name}</p>
                        <p style={{ fontSize: "12px", margin: "2px 0" }}>{xAxis}: {data.x}</p>
                        <p style={{ fontSize: "12px", margin: "2px 0" }}>{yAxis}: {data.y}</p>
                      </div>
                    );
                  }
                  return null;
                }}
              />
              <Scatter dataKey="y" fill={colors[0]} />
            </ScatterChart>
          </ResponsiveContainer>
        );
      
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={chartData.slice(0, 10)} // Limit to top 10 for readability
                dataKey="value"
                nameKey="name"
                cx="50%"
                cy="50%"
                outerRadius={120}
                label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(1)}%`}
              >
                {chartData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => [value.toLocaleString(), yAxis]} />
            </PieChart>
          </ResponsiveContainer>
        );
      
      default:
        return <div style={{ textAlign: "center", padding: "2rem", color: "#7f8c8d" }}>Select a chart type</div>;
    }
  };

  if (loading) {
    return (
      <div style={{ display: "flex", minHeight: "100vh" }}>
        <Sidebar />
<main style={{ flex: 1, padding: "2rem", background: "#ecf0f1", overflowX: "auto" }}>         
   <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "400px" }}>
            <div style={{ textAlign: "center" }}>
              <div style={{ 
                width: "64px", 
                height: "64px", 
                border: "4px solid #f3f3f3",
                borderTop: "4px solid #3498db",
                borderRadius: "50%",
                margin: "0 auto 1rem",
                animation: "spin 1s linear infinite"
              }}></div>
              <p style={{ fontSize: "18px", color: "#7f8c8d" }}>Loading dataset...</p>
            </div>
          </div>
        </main>
        <style>{`
          @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
          }
        `}</style>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", minHeight: "100vh" }}>
      <Sidebar />
      <main style={{ flex: 1, padding: "2rem", background: "#ecf0f1" }}>
        {/* Header */}
        <div style={{ background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", borderRadius: "12px", boxShadow: "0 4px 12px rgba(0,0,0,0.15)", padding: "2rem", marginBottom: "20px", color: "#fff" }}>
          <h1 style={{ fontSize: "32px", fontWeight: "bold", marginBottom: "1rem" }}>{name}</h1>
          <div style={{ display: "flex", alignItems: "center", gap: "2rem", opacity: 0.9 }}>
            <span style={{ display: "flex", alignItems: "center" }}>
              <span style={{ width: "8px", height: "8px", background: "rgba(255,255,255,0.8)", borderRadius: "50%", marginRight: "8px" }}></span>
              {records.length} Records
            </span>
            <span style={{ display: "flex", alignItems: "center" }}>
              <span style={{ width: "8px", height: "8px", background: "rgba(255,255,255,0.8)", borderRadius: "50%", marginRight: "8px" }}></span>
              {headers.length} Columns
            </span>
            <span style={{ display: "flex", alignItems: "center" }}>
              <span style={{ width: "8px", height: "8px", background: "rgba(255,255,255,0.8)", borderRadius: "50%", marginRight: "8px" }}></span>
              {chartData.length} Data Points
            </span>
          </div>
        </div>

        {/* Data Table Section */}
        <div style={{ background: "#fff", borderRadius: "12px", marginBottom: "20px", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>
          <div style={{ background: "#f8f9fa", padding: "1.5rem", borderBottom: "1px solid #e9ecef" }}>
            <h2 style={{ fontSize: "20px", fontWeight: "600", color: "#2c3e50", marginBottom: "4px" }}>📋 Data Table</h2>
            <p style={{ fontSize: "14px", color: "#7f8c8d", margin: 0 }}>View and manage your imported data</p>
          </div>
          <div style={{ padding: "1.5rem", overflowX: "auto", maxWidth: "100%" }}>
            <DataTable collectionName={name} />
          </div>
        </div>

        {/* Visualization Section - Dashboard Style */}
        <div style={{ background: "#fff", borderRadius: "12px", padding: "2rem", marginBottom: "20px", boxShadow: "0 2px 8px rgba(0,0,0,0.1)" }}>
          {/* Header */}
          <div style={{ marginBottom: "2rem" }}>
            <h2 style={{ fontSize: "28px", fontWeight: "bold", color: "#2c3e50", marginBottom: "8px" }}>
              Data Visualization
            </h2>
            <p style={{ color: "#7f8c8d", fontSize: "14px" }}>
              Configure and generate interactive charts from your dataset
            </p>
          </div>

          {/* Two Column Layout */}
          <div style={{ display: "grid", gridTemplateColumns: "320px 1fr", gap: "24px" }}>
            
            {/* Left Sidebar - Configuration Panel */}
            <div>
              {/* Chart Type Card */}
              <div style={{ background: "#f8f9fa", borderRadius: "8px", padding: "1.5rem", marginBottom: "20px", border: "1px solid #e9ecef" }}>
                <h3 style={{ fontSize: "16px", fontWeight: "bold", color: "#2c3e50", marginBottom: "16px", display: "flex", alignItems: "center" }}>
                  <span style={{ width: "4px", height: "20px", background: "#3498db", borderRadius: "2px", marginRight: "10px" }}></span>
                  Chart Type
                </h3>
                <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
                  {[
                    { value: 'bar', label: 'Bar Chart', icon: '📊', desc: 'Compare values across categories' },
                    { value: 'line', label: 'Line Chart', icon: '📈', desc: 'Show trends over time' },
                    { value: 'area', label: 'Area Chart', icon: '📉', desc: 'Display cumulative totals' },
                    { value: 'pie', label: 'Pie Chart', icon: '🥧', desc: 'Show proportions of a whole' },
                    { value: 'scatter', label: 'Scatter Plot', icon: '🔸', desc: 'Explore correlations' }
                  ].map(chart => (
                    <button
                      key={chart.value}
                      onClick={() => setChartType(chart.value)}
                      style={{
                        width: "100%",
                        textAlign: "left",
                        padding: "12px",
                        borderRadius: "8px",
                        border: chartType === chart.value ? "2px solid #3498db" : "1px solid #dee2e6",
                        background: chartType === chart.value ? "#e3f2fd" : "#fff",
                        cursor: "pointer",
                        transition: "all 0.2s",
                        display: "flex",
                        alignItems: "flex-start"
                      }}
                      onMouseEnter={(e) => {
                        if (chartType !== chart.value) {
                          e.currentTarget.style.borderColor = "#3498db";
                          e.currentTarget.style.boxShadow = "0 2px 4px rgba(52,152,219,0.1)";
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (chartType !== chart.value) {
                          e.currentTarget.style.borderColor = "#dee2e6";
                          e.currentTarget.style.boxShadow = "none";
                        }
                      }}
                    >
                      <span style={{ fontSize: "24px", marginRight: "12px" }}>{chart.icon}</span>
                      <div style={{ flex: 1 }}>
                        <div style={{ 
                          fontSize: "14px", 
                          fontWeight: "600", 
                          color: chartType === chart.value ? "#3498db" : "#2c3e50",
                          marginBottom: "4px"
                        }}>
                          {chart.label}
                        </div>
                        <div style={{ fontSize: "11px", color: "#7f8c8d", lineHeight: "1.3" }}>
                          {chart.desc}
                        </div>
                      </div>
                      {chartType === chart.value && (
                        <span style={{ color: "#3498db", fontSize: "18px", fontWeight: "bold" }}>✓</span>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Axis Configuration Card */}
<div
  style={{
    background: "#f8f9fa",
    borderRadius: "8px",
    padding: "1.5rem",
    marginBottom: "20px",
    border: "1px solid #e9ecef",
  }}
>
  <h3
    style={{
      fontSize: "16px",
      fontWeight: "bold",
      color: "#2c3e50",
      marginBottom: "16px",
      display: "flex",
      alignItems: "center",
    }}
  >
    <span
      style={{
        width: "4px",
        height: "20px",
        background: "#9b59b6",
        borderRadius: "2px",
        marginRight: "10px",
      }}
    ></span>
    Axis Configuration
  </h3>

  {/* X-Axis */}
  <div
    style={{
      background: "#fff",
      padding: "16px",
      borderRadius: "8px",
      marginBottom: "12px",
      border: "1px solid #dee2e6",
    }}
  >
    <label
      style={{
        fontSize: "13px",
        fontWeight: "600",
        color: "#2c3e50",
        marginBottom: "8px",
        display: "flex",
        alignItems: "center",
      }}
    >
      <span style={{ marginRight: "8px" }}>→</span>
      X-Axis (Horizontal)
    </label>
    <select
      value={xAxis}
      onChange={(e) => setXAxis(e.target.value)}
      style={{
        width: "100%",
        padding: "10px",
        borderRadius: "6px",
        border: "1px solid #ced4da",
        fontSize: "14px",
        marginBottom: "8px",
      }}
    >
      {headers.map((header) => (
        <option key={header} value={header}>
          {header}
        </option>
      ))}
    </select>
    <span
      style={{
        display: "inline-block",
        padding: "4px 10px",
        borderRadius: "12px",
        fontSize: "11px",
        fontWeight: "600",
        background:
          getColumnType(xAxis) === "numeric"
            ? "#3498db"
            : getColumnType(xAxis) === "date"
            ? "#2ecc71"
            : "#9b59b6",
        color: "#fff",
      }}
    >
      {getColumnType(xAxis).toUpperCase()}
    </span>
  </div>

  {/* 🔄 Swap Button */}
  <div style={{ textAlign: "center", marginBottom: "12px" }}>
    <button
      type="button"
      onClick={() => {
        const oldX = xAxis;
        const oldY = yAxis;
        setXAxis(oldY);
        setYAxis(oldX);
      }}
      style={{
        background: "linear-gradient(90deg, #9b59b6, #8e44ad)",
        color: "white",
        border: "none",
        padding: "8px 14px",
        borderRadius: "6px",
        cursor: "pointer",
        fontSize: "13px",
        fontWeight: "600",
        display: "inline-flex",
        alignItems: "center",
        gap: "6px",
        transition: "transform 0.15s ease",
      }}
      onMouseEnter={(e) => (e.currentTarget.style.transform = "scale(1.05)")}
      onMouseLeave={(e) => (e.currentTarget.style.transform = "scale(1)")}
    >
      🔄 Swap Axes
    </button>
  </div>

  {/* Y-Axis */}
  <div
    style={{
      background: "#fff",
      padding: "16px",
      borderRadius: "8px",
      border: "1px solid #dee2e6",
    }}
  >
    <label
      style={{
        fontSize: "13px",
        fontWeight: "600",
        color: "#2c3e50",
        marginBottom: "8px",
        display: "flex",
        alignItems: "center",
      }}
    >
      <span style={{ marginRight: "8px" }}>↑</span>
      Y-Axis (Vertical)
    </label>
    <select
      value={yAxis}
      onChange={(e) => setYAxis(e.target.value)}
      style={{
        width: "100%",
        padding: "10px",
        borderRadius: "6px",
        border: "1px solid #ced4da",
        fontSize: "14px",
        marginBottom: "8px",
      }}
    >
      {headers.map((header) => (
        <option key={header} value={header}>
          {header}
        </option>
      ))}
    </select>
    <span
      style={{
        display: "inline-block",
        padding: "4px 10px",
        borderRadius: "12px",
        fontSize: "11px",
        fontWeight: "600",
        background:
          getColumnType(yAxis) === "numeric"
            ? "#3498db"
            : getColumnType(yAxis) === "date"
            ? "#2ecc71"
            : "#9b59b6",
        color: "#fff",
      }}
    >
      {getColumnType(yAxis).toUpperCase()}
    </span>
  </div>
</div>


              {/* Quick Stats Card */}
              <div style={{ background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", borderRadius: "8px", padding: "1.5rem", color: "#fff" }}>
                <h4 style={{ fontSize: "12px", fontWeight: "600", marginBottom: "16px", opacity: 0.9, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                  Quick Stats
                </h4>
                <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
                  <div style={{ background: "rgba(255,255,255,0.15)", padding: "14px", borderRadius: "6px", backdropFilter: "blur(10px)" }}>
                    <div style={{ fontSize: "11px", marginBottom: "4px", opacity: 0.9 }}>Data Points</div>
                    <div style={{ fontSize: "28px", fontWeight: "bold" }}>{chartData.length}</div>
                  </div>
                  <div style={{ background: "rgba(255,255,255,0.15)", padding: "14px", borderRadius: "6px", backdropFilter: "blur(10px)" }}>
                    <div style={{ fontSize: "11px", marginBottom: "4px", opacity: 0.9 }}>Total Records</div>
                    <div style={{ fontSize: "28px", fontWeight: "bold" }}>{records.length}</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Side - Chart Display */}
            <div>
              {/* Chart Header */}
              <div style={{ marginBottom: "20px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px" }}>
                  <div>
                    <h3 style={{ fontSize: "20px", fontWeight: "bold", color: "#2c3e50", marginBottom: "4px", textTransform: "capitalize" }}>
                      {chartType} Chart
                    </h3>
                    <p style={{ fontSize: "14px", color: "#7f8c8d" }}>
                      <strong style={{ color: "#3498db" }}>{xAxis}</strong> vs <strong style={{ color: "#9b59b6" }}>{yAxis}</strong>
                    </p>
                  </div>
                  <div style={{ 
                    display: "flex", 
                    alignItems: "center", 
                    gap: "8px",
                    background: "#d4edda",
                    padding: "6px 12px",
                    borderRadius: "20px",
                    border: "1px solid #c3e6cb"
                  }}>
                    <span style={{ 
                      width: "8px", 
                      height: "8px", 
                      background: "#28a745", 
                      borderRadius: "50%",
                      animation: "pulse 2s infinite"
                    }}></span>
                    <span style={{ fontSize: "12px", fontWeight: "600", color: "#155724" }}>Live Preview</span>
                  </div>
                </div>
                <div style={{ height: "3px", width: "100%", background: "linear-gradient(90deg, #3498db 0%, #9b59b6 50%, #e74c3c 100%)", borderRadius: "2px" }}></div>
              </div>

              {/* Chart Container */}
              <div style={{ background: "#fafbfc", padding: "2rem", borderRadius: "8px", border: "1px solid #e9ecef", marginBottom: "20px" }}>
                {renderChart()}
              </div>

              {/* Chart Info Cards */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: "16px" }}>
                <div style={{ background: "#e3f2fd", padding: "16px", borderRadius: "8px", border: "1px solid #bbdefb" }}>
                  <div style={{ display: "flex", alignItems: "center", marginBottom: "8px" }}>
                    <span style={{ fontSize: "20px", marginRight: "8px" }}>📊</span>
                    <div style={{ fontSize: "11px", fontWeight: "600", color: "#1976d2", textTransform: "uppercase" }}>Chart Type</div>
                  </div>
                  <div style={{ fontSize: "20px", fontWeight: "bold", color: "#1565c0", textTransform: "capitalize" }}>
                    {chartType}
                  </div>
                </div>

                <div style={{ background: "#f3e5f5", padding: "16px", borderRadius: "8px", border: "1px solid #e1bee7" }}>
                  <div style={{ display: "flex", alignItems: "center", marginBottom: "8px" }}>
                    <span style={{ fontSize: "20px", marginRight: "8px" }}>→</span>
                    <div style={{ fontSize: "11px", fontWeight: "600", color: "#7b1fa2", textTransform: "uppercase" }}>X-Axis Type</div>
                  </div>
                  <div style={{ fontSize: "20px", fontWeight: "bold", color: "#6a1b9a", textTransform: "capitalize" }}>
                    {getColumnType(xAxis)}
                  </div>
                </div>

                <div style={{ background: "#fce4ec", padding: "16px", borderRadius: "8px", border: "1px solid #f8bbd0" }}>
                  <div style={{ display: "flex", alignItems: "center", marginBottom: "8px" }}>
                    <span style={{ fontSize: "20px", marginRight: "8px" }}>↑</span>
                    <div style={{ fontSize: "11px", fontWeight: "600", color: "#c2185b", textTransform: "uppercase" }}>Y-Axis Type</div>
                  </div>
                  <div style={{ fontSize: "20px", fontWeight: "bold", color: "#ad1457", textTransform: "capitalize" }}>
                    {getColumnType(yAxis)}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <style>{`
        @keyframes pulse {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.5; }
        }
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}