import React, { useState } from "react";

export default function Login({ setLoggedIn }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError("");
    
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (username === "admin" && password === "1234") {
      setLoggedIn(true);
    } else {
      setError("Invalid credentials. Try admin / 1234");
    }
    setIsLoading(false);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "linear-gradient(135deg, #0e4c92 0%, #1e3a8a 50%, #1e293b 100%)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "1rem",
      fontFamily: "-apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif",
      position: "relative",
      overflow: "hidden"
    }}>
      
      {/* Animated Philippine Map Background */}
      <div style={{
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: "100%",
        maxWidth: "1200px",
        height: "100%",
        opacity: 0.1,
        pointerEvents: "none"
      }}>
        <svg viewBox="0 0 800 600" style={{ width: "100%", height: "100%" }}>
          {/* Simplified Philippine archipelago shapes */}
          <path d="M 350 100 L 370 120 L 365 145 L 380 160 L 375 180 L 360 175 L 345 155 L 340 130 Z" 
                fill="white" opacity="0.3" style={{ animation: "float 6s ease-in-out infinite" }} />
          <path d="M 320 200 L 340 210 L 350 240 L 370 260 L 380 290 L 360 300 L 340 285 L 325 260 L 310 230 Z" 
                fill="white" opacity="0.3" style={{ animation: "float 8s ease-in-out infinite 1s" }} />
          <path d="M 400 280 L 430 290 L 450 320 L 460 350 L 440 360 L 420 340 L 410 310 Z" 
                fill="white" opacity="0.3" style={{ animation: "float 7s ease-in-out infinite 0.5s" }} />
        </svg>
      </div>

      {/* Floating emigrant icons */}
      <div style={{ position: "absolute", top: "10%", left: "15%", fontSize: "5rem", opacity: 0.2, animation: "float 3s ease-in-out infinite" }}>✈️</div>
      <div style={{ position: "absolute", top: "20%", right: "20%", fontSize: "4rem", opacity: 0.2, animation: "float 3s ease-in-out infinite 1s" }}>🌏</div>
      <div style={{ position: "absolute", bottom: "15%", left: "28%", fontSize: "6rem", opacity: 0.2, animation: "float 3s ease-in-out infinite 0.5s" }}>🛫</div>
      <div style={{ position: "absolute", bottom: "25%", right: "15%", fontSize: "4rem", opacity: 0.2, animation: "float 3s ease-in-out infinite 1.5s" }}>🏠</div>
      <div style={{ position: "absolute", top: "40%", left: "5%", fontSize: "4rem", opacity: 0.15, animation: "float 3s ease-in-out infinite 2s" }}>🧳</div>
      <div style={{ position: "absolute", top: "30%", left: "30%", fontSize: "6rem", opacity: 0.15, animation: "float 3s ease-in-out infinite 2s" }}>🌏</div>
      <div style={{ position: "absolute", top: "60%", right: "8%", fontSize: "4rem", opacity: 0.15, animation: "float 3s ease-in-out infinite 0.8s" }}>🌐</div>

      {/* Login Card */}
      <div style={{
        position: "relative",
        zIndex: 10,
        width: "100%",
        maxWidth: "28rem",
        background: "rgba(255, 255, 255, 0.95)",
        backdropFilter: "blur(16px)",
        border: "1px solid rgba(255, 255, 255, 0.3)",
        borderRadius: "1.5rem",
        boxShadow: "0 25px 50px -12px rgba(0, 0, 0, 0.4)",
        padding: "2rem",
        overflow: "hidden"
      }}>
        
        {/* Philippine flag colors accent bar */}
        <div style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: "4px",
          background: "linear-gradient(90deg, #0038a8 0%, #ce1126 50%, #fcd116 100%)"
        }}></div>

        {/* Header with Philippine theme */}
        <div style={{ textAlign: "center", marginBottom: "2rem" }}>
          <div style={{
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            width: "5rem",
            height: "5rem",
            background: "linear-gradient(135deg, #0e4c92, #1e3a8a)",
            borderRadius: "50%",
            marginBottom: "1rem",
            boxShadow: "0 10px 25px rgba(14, 76, 146, 0.3)",
            position: "relative"
          }}>
            <div style={{ fontSize: "2.5rem" }}>🇵🇭</div>
            <div style={{
              position: "absolute",
              top: "-5px",
              right: "-15px",
              width: "2.5rem",
              height: "2.5rem",
              background: "#ce1126",
              borderRadius: "50%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: "1.2rem",
              boxShadow: "0 2px 8px rgba(0,0,0,0.2)"
            }}>
              ✈️
            </div>
          </div>
          
          <h2 style={{
            fontSize: "1.875rem",
            fontWeight: "bold",
            color: "#1e293b",
            marginBottom: "0.5rem"
          }}>
            Filipino Emigrants
          </h2>
          <p style={{
            color: "#64748b",
            fontSize: "0.875rem",
            marginBottom: "0.5rem"
          }}>
            Data Management System
          </p>
          <div style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "0.5rem",
            background: "linear-gradient(135deg, #fef3c7, #fde68a)",
            padding: "0.5rem 1rem",
            borderRadius: "1rem",
            fontSize: "0.75rem",
            fontWeight: "600",
            color: "#92400e"
          }}>
            <span>🌏</span>
            <span>Philippine Migration Analytics</span>
          </div>
        </div>

        {/* Stats preview */}
        <div style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr 1fr",
          gap: "0.5rem",
          marginBottom: "1.5rem"
        }}>
          {[
            { icon: "👥", label: "Emigrants", value: "2.1M" },
            { icon: "🗺️", label: "Regions", value: "17" },
            { icon: "📊", label: "Years", value: "30+" }
          ].map((stat, i) => (
            <div key={i} style={{
              background: "linear-gradient(135deg, #f0f9ff, #e0f2fe)",
              padding: "0.75rem",
              borderRadius: "0.75rem",
              textAlign: "center",
              border: "1px solid #bae6fd"
            }}>
              <div style={{ fontSize: "1.25rem", marginBottom: "0.25rem" }}>{stat.icon}</div>
              <div style={{ fontSize: "1rem", fontWeight: "bold", color: "#0c4a6e", marginBottom: "0.125rem" }}>{stat.value}</div>
              <div style={{ fontSize: "0.625rem", color: "#64748b" }}>{stat.label}</div>
            </div>
          ))}
        </div>

        <form onSubmit={handleLogin}>
          {/* Username field */}
          <div style={{ position: "relative", marginBottom: "1rem" }}>
            <div style={{
              position: "absolute",
              left: "1rem",
              top: "50%",
              transform: "translateY(-50%)",
              fontSize: "1.125rem",
              opacity: 0.6
            }}>
              👤
            </div>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              style={{
                width: "100%",
                padding: "0.875rem 1rem 0.875rem 3rem",
                background: "#f8fafc",
                border: "2px solid #e2e8f0",
                borderRadius: "0.75rem",
                color: "#1e293b",
                fontSize: "1rem",
                outline: "none",
                transition: "all 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#0e4c92";
                e.target.style.background = "#ffffff";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e2e8f0";
                e.target.style.background = "#f8fafc";
              }}
              required
            />
          </div>

          {/* Password field */}
          <div style={{ position: "relative", marginBottom: "1rem" }}>
            <div style={{
              position: "absolute",
              left: "1rem",
              top: "50%",
              transform: "translateY(-50%)",
              fontSize: "1.125rem",
              opacity: 0.6
            }}>
              🔒
            </div>
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              style={{
                width: "100%",
                padding: "0.875rem 3rem 0.875rem 3rem",
                background: "#f8fafc",
                border: "2px solid #e2e8f0",
                borderRadius: "0.75rem",
                color: "#1e293b",
                fontSize: "1rem",
                outline: "none",
                transition: "all 0.2s ease",
                boxSizing: "border-box"
              }}
              onFocus={(e) => {
                e.target.style.borderColor = "#0e4c92";
                e.target.style.background = "#ffffff";
              }}
              onBlur={(e) => {
                e.target.style.borderColor = "#e2e8f0";
                e.target.style.background = "#f8fafc";
              }}
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              style={{
                position: "absolute",
                right: "1rem",
                top: "50%",
                transform: "translateY(-50%)",
                background: "none",
                border: "none",
                cursor: "pointer",
                fontSize: "1.125rem",
                opacity: 0.6
              }}
            >
              {showPassword ? "🙈" : "👁️"}
            </button>
          </div>

          {/* Error message */}
          {error && (
            <div style={{
              background: "linear-gradient(135deg, #fee2e2, #fecaca)",
              border: "2px solid #fca5a5",
              borderRadius: "0.75rem",
              padding: "0.75rem",
              color: "#991b1b",
              fontSize: "0.875rem",
              marginBottom: "1rem",
              display: "flex",
              alignItems: "center",
              gap: "0.5rem"
            }}>
              <span>⚠️</span>
              <span>{error}</span>
            </div>
          )}

          

          {/* Login button */}
          <button
            type="submit"
            disabled={isLoading}
            style={{
              width: "100%",
              padding: "1rem",
              background: isLoading 
                ? "#94a3b8" 
                : "linear-gradient(135deg, #0e4c92, #1e3a8a)",
              color: "white",
              fontWeight: "700",
              border: "none",
              borderRadius: "0.75rem",
              cursor: isLoading ? "not-allowed" : "pointer",
              fontSize: "1rem",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "0.5rem",
              transition: "all 0.2s ease",
              boxSizing: "border-box",
              boxShadow: isLoading ? "none" : "0 4px 14px rgba(14, 76, 146, 0.4)"
            }}
            onMouseEnter={(e) => {
              if (!isLoading) {
                e.target.style.transform = "translateY(-2px)";
                e.target.style.boxShadow = "0 6px 20px rgba(14, 76, 146, 0.5)";
              }
            }}
            onMouseLeave={(e) => {
              if (!isLoading) {
                e.target.style.transform = "translateY(0)";
                e.target.style.boxShadow = "0 4px 14px rgba(14, 76, 146, 0.4)";
              }
            }}
          >
            {isLoading ? (
              <>
                <div style={{
                  width: "1.25rem",
                  height: "1.25rem",
                  border: "2px solid white",
                  borderTop: "2px solid transparent",
                  borderRadius: "50%",
                  animation: "spin 1s linear infinite"
                }}></div>
                <span>Authenticating...</span>
              </>
            ) : (
              <>
                <span>🔐</span>
                <span>Access Dashboard</span>
              </>
            )}
          </button>
        </form>

        {/* Footer */}
        <div style={{
          marginTop: "1.5rem",
          textAlign: "center",
          fontSize: "0.75rem",
          color: "#64748b"
        }}>
          <div style={{ marginBottom: "0.5rem" }}>
            Carl Joseph Samson * The Goat
          </div>
          <div>
            Secure Access • Data Privacy Protected
          </div>
        </div>
      </div>

      <style>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-20px); }
        }
        @keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
        input::placeholder {
          color: #94a3b8;
        }
      `}</style>
    </div>
  );
}