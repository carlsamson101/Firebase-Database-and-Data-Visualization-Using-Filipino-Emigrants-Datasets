import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line
} from "recharts";
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps";
import geoData from "../ph.json";
import Layout from "../components/Layout";
import { db } from "../firebase";
import { collection, getDocs } from "firebase/firestore";

// 🧭 Map of GeoJSON name → Firebase region key
const regionNameMap = {
  "Ilocos": "Region I - Ilocos Region",
  "Cagayan Valley": "Region II - Cagayan Valley",
  "Central Luzon": "Region III - Central Luzon",
  "Calabarzon": "Region IV A - CALABARZON",
  "Mimaropa": "Region IV B - MIMAROPA",
  "Bicol": "Region V - Bicol Region",
  "Western Visayas": "Region VI - Western Visayas",
  "Central Visayas": "Region VII - Central Visayas",
  "Eastern Visayas": "Region VIII - Eastern Visayas",
  "Zamboanga Peninsula": "Region IX - Zamboanga Peninsula",
  "Northern Mindanao": "Region X - Northern Mindanao",
  "Davao": "Region XI - Davao Region",
  "Soccsksargen": "Region XII - SOCCSKSARGEN",
  "Caraga": "Region XIII - Caraga",
  "Autonomous Region in Muslim Mindanao": "Autonomous Region in Muslim Mindanao (ARMM)",
  "Cordillera Administrative Region": "Cordillera Administrative Region (CAR)",
  "National Capital Region": "National Capital Region (NCR)",
};

const COLORS = ["#e74c3c", "#2ecc71", "#9b59b6", "#f1c40f", "#1abc9c", "#3498db", "#e67e22"];

export default function Dashboard() {
  const navigate = useNavigate();
  const [regionData, setRegionData] = useState({});
  const [ageData, setAgeData] = useState([]);
  const [sexData, setSexData] = useState([]);
  const [availableYears, setAvailableYears] = useState([]);
  const [mapYear, setMapYear] = useState("");
  const [ageYear, setAgeYear] = useState("");
  const [sexYear, setSexYear] = useState("");
  const [loading, setLoading] = useState(true);
  const [trendsDataset, setTrendsDataset] = useState("sex"); // sex, age, or region
  const [civilStatusData, setCivilStatusData] = useState([]);
const [civilStatusYear, setCivilStatusYear] = useState("");
const [heatmapDataset, setHeatmapDataset] = useState("age"); // age, civil, or region

  // ✅ Fetch all data from Firebase
  useEffect(() => {
    const fetchAllData = async () => {
      try {
        setLoading(true);

        // Fetch Region data
        const regionSnapshot = await getDocs(collection(db, "Region"));
        const regData = {};
        regionSnapshot.forEach(doc => {
          const docData = doc.data();
          const regionName = docData.REGION;
          if (regionName) {
            regData[regionName] = docData;
          }
        });
        setRegionData(regData);

        // Extract years from the first region
        let years = [];
        if (Object.keys(regData).length > 0) {
          const first = Object.values(regData)[0];
          years = Object.keys(first).filter(y => /^\d{4}$/.test(y)).sort();
          setAvailableYears(years);
          const latestYear = years[years.length - 1];
          setMapYear(latestYear);
          setAgeYear(latestYear);
          setSexYear(latestYear);
          setCivilStatusYear(latestYear);
        }

        // Fetch Age data
        const ageSnapshot = await getDocs(collection(db, "Age"));
        const ageArr = [];
        ageSnapshot.forEach(doc => {
          const docData = doc.data();
          ageArr.push(docData);
        });
        setAgeData(ageArr);

       // Fetch Sex data
      const sexSnapshot = await getDocs(collection(db, "Sex"));
      const sexArr = [];
      sexSnapshot.forEach(doc => {
        const docData = doc.data();
        sexArr.push(docData);
      });
      setSexData(sexArr);

      // Fetch Civil Status data
      const civilStatusSnapshot = await getDocs(collection(db, "Civil_Status"));
      const civilArr = [];
      civilStatusSnapshot.forEach(doc => {
        const docData = doc.data();
        civilArr.push(docData);
      });
      setCivilStatusData(civilArr);

      setLoading(false);
      } catch (err) {
        console.error("Error fetching data:", err);
        setLoading(false);
      }
    };

    fetchAllData();
  }, []);

  // 🧮 Process Age data for the selected year (Bar Chart)
  const processedAgeData = React.useMemo(() => {
  if (!ageYear || ageData.length === 0) return [];
  
  return ageData
    .filter(item => {
      const ageGroup = item["AGE GROUP"] || item[" AGE GROUP"];
      return ageGroup && ageGroup.trim() !== ""; // Exclude empty/TOTAL rows
    })
    .map(item => {
      const ageGroup = item["AGE GROUP"] || item[" AGE GROUP"];
      const rawValue = item[ageYear];
      // Remove quotes and spaces, then parse
      const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
      const count = parseInt(cleanValue, 10);
      return {
        ageGroup,
        count: isNaN(count) ? 0 : count
      };
    }).filter(item => item.count > 0);
  }, [ageData, ageYear]);

    // 🧮 Process Sex data for the selected year (Pie Chart)
  const processedSexData = React.useMemo(() => {
    if (!sexYear || sexData.length === 0) return [];
    
    // Debug: Log first document to see structure
    if (sexData.length > 0) {
      console.log("First Sex Document:", sexData[0]);
      console.log("Looking for year:", sexYear);
    }
    
    // Find the document that matches the selected year
    const yearDoc = sexData.find(item => {
      // Try different variations with spaces in field names
      const year = item["  YEAR"] || item[" YEAR"] || item.YEAR || item.Year || item.year;
      const cleanYear = year ? String(year).replace(/["'\s]/g, "") : "";
      console.log("Comparing:", cleanYear, "===", sexYear, "?", cleanYear === sexYear);
      return cleanYear === sexYear;
    });

    console.log("Found yearDoc:", yearDoc);
    
    if (!yearDoc) {
      return [];
    }
    
    // Extract male and female counts
    const result = [];
    
    const maleValue = yearDoc[" MALE"] || yearDoc.MALE || yearDoc.Male || yearDoc.male;
    if (maleValue) {
      const cleanMale = String(maleValue).replace(/["'\s,]/g, "");
      const maleCount = parseInt(cleanMale, 10);
      if (!isNaN(maleCount) && maleCount > 0) {
        result.push({ sex: "Male", count: maleCount });
      }
    }
    
    const femaleValue = yearDoc[" FEMALE"] || yearDoc.FEMALE || yearDoc.Female || yearDoc.female;
    if (femaleValue) {
      const cleanFemale = String(femaleValue).replace(/["'\s,]/g, "");
      const femaleCount = parseInt(cleanFemale, 10);
      if (!isNaN(femaleCount) && femaleCount > 0) {
        result.push({ sex: "Female", count: femaleCount });
      }
    }
    
    console.log("Result:", result);
    return result;
  }, [sexData, sexYear]);


// 🧮 Process Sex data for timeline (Line Chart)
  // 🧮 Process timeline data based on selected dataset
  const timelineData = React.useMemo(() => {
    if (trendsDataset === "sex") {
      // Get data from Sex collection (Total emigrants)
      if (sexData.length === 0) return [];
      
      return sexData.map(item => {
        const year = item["  YEAR"] || item[" YEAR"] || item.YEAR || item.Year || item.year;
        const cleanYear = year ? String(year).replace(/["'\s]/g, "") : "";
        
        const totalValue = item[" TOTAL"] || item.TOTAL || item.Total || item.total;
        const cleanTotal = totalValue ? String(totalValue).replace(/["'\s,]/g, "") : "0";
        const count = parseInt(cleanTotal, 10);
        
        return { year: cleanYear, count: isNaN(count) ? 0 : count };
      }).filter(item => {
        return item.year && item.count > 0 && /^\d{4}$/.test(item.year);
      }).sort((a, b) => parseInt(a.year) - parseInt(b.year));
      
    } else if (trendsDataset === "age") {
      // Get data from Age collection (Sum of all age groups)
      if (ageData.length === 0 || availableYears.length === 0) return [];
      
      return availableYears.map(year => {
        const total = ageData.reduce((sum, item) => {
          const rawValue = item[year];
          const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
          const count = parseInt(cleanValue, 10);
          return sum + (isNaN(count) ? 0 : count);
        }, 0);
        return { year, count: total };
      });
      
    } else if (trendsDataset === "region") {
      // Get data from Region collection (Sum of all regions)
      if (Object.keys(regionData).length === 0 || availableYears.length === 0) return [];
      
      return availableYears.map(year => {
        const total = Object.values(regionData).reduce((sum, region) => {
          const rawValue = region[year];
          const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
          const count = parseInt(cleanValue, 10);
          return sum + (isNaN(count) ? 0 : count);
        }, 0);
        return { year, count: total };
      });
    }
    
    return [];
  }, [trendsDataset, sexData, ageData, regionData, availableYears]);
  
  // Get chart title based on dataset
  const trendsTitle = trendsDataset === "sex" 
    ? "Trends: Total Emigrants per Year (by Sex Data)"
    : trendsDataset === "age"
    ? "Trends: Total Emigrants per Year (by Age Groups)"
    : "Trends: Total Emigrants per Year (by Region)";


  // 🧮 Process Civil Status data for area chart (all years)
// 🧮 Process Civil Status data for distribution (single year)
const processedCivilStatusData = React.useMemo(() => {
  if (!civilStatusYear || civilStatusData.length === 0) return [];
  
  // Find the document for the selected year
  const yearDoc = civilStatusData.find(item => {
    const year = item["YEAR"] || item[" YEAR"] || item["  YEAR"];
    const cleanYear = year ? String(year).replace(/["'\s]/g, "") : "";
    return cleanYear === civilStatusYear;
  });

  if (!yearDoc) return [];

  // Extract all civil status categories
  const result = [];
  const categories = ["Single", "Married", "Divorced", "Separated", "Widower", "Not Reported"];
  
  categories.forEach(category => {
    const value = yearDoc[category] || yearDoc[` ${category}`] || yearDoc[`  ${category}`];
    if (value) {
      const cleanValue = String(value).replace(/["\s,]/g, "");
      const count = parseInt(cleanValue, 10);
      if (!isNaN(count) && count > 0) {
        result.push({ category, count });
      }
    }
  });
  
  return result.sort((a, b) => b.count - a.count);
}, [civilStatusData, civilStatusYear]);

// 📊 Calculate Key Insights
const insights = React.useMemo(() => {
  if (Object.keys(regionData).length === 0 || availableYears.length === 0) {
    return {
      totalEmigrants: 0,
      topRegion: { name: "N/A", count: 0 },
      topAgeGroup: { name: "N/A", count: 0 },
      dominantSex: { name: "N/A", percentage: 0 },
      yearOverYearChange: 0,
      topCivilStatus: { name: "N/A", count: 0 },
      latestYear: ""
    };
  }

  const latestYear = availableYears[availableYears.length - 1];
  const previousYear = availableYears[availableYears.length - 2];

  // 1. Total Emigrants (latest year) - Sum all regions OR use TOTAL row
  let totalEmigrantsLatest = 0;
  const totalRow = regionData["TOTAL"] || regionData["Total"];
  
  if (totalRow && latestYear) {
    const rawValue = totalRow[latestYear];
    const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
    totalEmigrantsLatest = parseInt(cleanValue, 10) || 0;
  }
  
  // If TOTAL row doesn't exist or is 0, sum all regions
  if (totalEmigrantsLatest === 0) {
    totalEmigrantsLatest = Object.entries(regionData)
      .filter(([name]) => name !== "TOTAL" && name !== "Total")
      .reduce((sum, [name, data]) => {
        const rawValue = data[latestYear];
        const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
        const count = parseInt(cleanValue, 10) || 0;
        return sum + count;
      }, 0);
  }

// 2. Top Region (latest year) - EXCLUDE TOTAL
let topRegion = { name: "N/A", count: 0 };
Object.entries(regionData)
  .filter(([name]) => {
    // Exclude any variation of TOTAL
    const upperName = name.toUpperCase().trim();
    return upperName !== "TOTAL" && 
           upperName !== "TOTAL:" && 
           !upperName.startsWith("TOTAL") &&
           !upperName.includes("NOT REPORTED") &&
           !upperName.includes("NO RESPONSE");
  })
  .forEach(([name, data]) => {
    const rawValue = data[latestYear];
    const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
    const count = parseInt(cleanValue, 10) || 0;
    
    // Debug: log what we're checking
    console.log(`Checking region: ${name}, count: ${count}`);
    
    if (count > topRegion.count) {
      topRegion = { 
        name: name
          .replace(/Region [IVX]+ - /g, '')
          .replace(/Region [0-9]+ - /g, '')
          .replace(/Region XIII - /g, '')
          .replace(/\([^)]*\)/g, '')
          .trim(),
        count 
      };
    }
  });

  // 3. Top Age Group (latest year)
  let topAgeGroup = { name: "N/A", count: 0 };
  if (ageData.length > 0 && latestYear) {
    ageData.forEach(item => {
      const ageGroup = item["AGE GROUP"] || item[" AGE GROUP"] || "Unknown";
      const rawValue = item[latestYear];
      const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
      const count = parseInt(cleanValue, 10) || 0;
      
      if (count > topAgeGroup.count && ageGroup !== "Unknown") {
        topAgeGroup = { name: ageGroup, count };
      }
    });
  }

  // 4. Dominant Sex (latest year)
  let dominantSex = { name: "N/A", percentage: 0 };
  if (sexData.length > 0 && latestYear) {
    const latestSexDoc = sexData.find(item => {
      const year = item["  YEAR"] || item[" YEAR"] || item["YEAR"] || item.YEAR;
      const cleanYear = year ? String(year).replace(/["'\s]/g, "") : "";
      return cleanYear === latestYear;
    });
    
    if (latestSexDoc) {
      const maleValue = latestSexDoc[" MALE"] || latestSexDoc["MALE"] || latestSexDoc.MALE || "0";
      const femaleValue = latestSexDoc[" FEMALE"] || latestSexDoc["FEMALE"] || latestSexDoc.FEMALE || "0";
      const totalValue = latestSexDoc[" TOTAL"] || latestSexDoc["TOTAL"] || latestSexDoc.TOTAL || "0";
      
      const male = parseInt(String(maleValue).replace(/["\s,]/g, ""), 10) || 0;
      const female = parseInt(String(femaleValue).replace(/["\s,]/g, ""), 10) || 0;
      const total = parseInt(String(totalValue).replace(/["\s,]/g, ""), 10) || 0;
      
      if (total > 0) {
        if (male > female) {
          dominantSex = { name: "Male", percentage: (male / total * 100).toFixed(1) };
        } else {
          dominantSex = { name: "Female", percentage: (female / total * 100).toFixed(1) };
        }
      }
    }
  }

  // 5. Year-over-Year Change
let yearOverYearChange = 0;
console.log("YoY Debug:", { latestYear, previousYear, hasTotalRow: !!totalRow });

if (previousYear && latestYear) {
  // Get current year total
  let current = 0;
  if (totalRow && totalRow[latestYear]) {
    const currentValue = totalRow[latestYear];
    current = parseInt(String(currentValue).replace(/["\s,]/g, ""), 10) || 0;
  } else {
    // Sum all regions for current year if no TOTAL row
    current = Object.entries(regionData)
      .filter(([name]) => {
        const cleanName = name.toUpperCase().trim();
        return cleanName !== "TOTAL" && cleanName !== "TOTAL:";
      })
      .reduce((sum, [name, data]) => {
        const rawValue = data[latestYear];
        const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
        return sum + (parseInt(cleanValue, 10) || 0);
      }, 0);
  }

  // Get previous year total
  let previous = 0;
  if (totalRow && totalRow[previousYear]) {
    const previousValue = totalRow[previousYear];
    previous = parseInt(String(previousValue).replace(/["\s,]/g, ""), 10) || 0;
  } else {
    // Sum all regions for previous year if no TOTAL row
    previous = Object.entries(regionData)
      .filter(([name]) => {
        const cleanName = name.toUpperCase().trim();
        return cleanName !== "TOTAL" && cleanName !== "TOTAL:";
      })
      .reduce((sum, [name, data]) => {
        const rawValue = data[previousYear];
        const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
        return sum + (parseInt(cleanValue, 10) || 0);
      }, 0);
  }

  console.log("YoY Values:", { current, previous, latestYear, previousYear });

  if (previous > 0) {
    yearOverYearChange = ((current - previous) / previous * 100);
  }
}

console.log("YoY Change:", yearOverYearChange);

  // 6. Top Civil Status (latest year)
  let topCivilStatus = { name: "N/A", count: 0 };
  if (civilStatusData.length > 0 && latestYear) {
    const latestCivilDoc = civilStatusData.find(item => {
      const year = item["YEAR"] || item[" YEAR"] || item["  YEAR"];
      const cleanYear = year ? String(year).replace(/["'\s]/g, "") : "";
      return cleanYear === latestYear;
    });

    if (latestCivilDoc) {
      const categories = ["Single", "Married", "Divorced", "Separated", "Widower", "Not Reported"];
      categories.forEach(category => {
        const value = latestCivilDoc[category] || latestCivilDoc[` ${category}`] || latestCivilDoc[`  ${category}`];
        const count = parseInt(String(value || "0").replace(/["\s,]/g, ""), 10) || 0;
        if (count > topCivilStatus.count) {
          topCivilStatus = { name: category, count };
        }
      });
    }
  }

  return {
    totalEmigrants: totalEmigrantsLatest,
    topRegion,
    topAgeGroup,
    dominantSex,
    yearOverYearChange,
    topCivilStatus,
    latestYear
  };
}, [regionData, ageData, sexData, civilStatusData, availableYears]);

 // 🧮 Total emigrants for map
  const totalEmigrants = React.useMemo(() => {
    // First, check if there's a TOTAL row in the region data
    const totalRow = regionData["TOTAL"] || regionData["Total"];
    if (totalRow && mapYear) {
      const rawValue = totalRow[mapYear];
      const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
      const count = parseInt(cleanValue, 10);
      if (!isNaN(count) && count > 0) {
        return count;
      }
    }
    
    // Otherwise, sum all regions (excluding TOTAL row if it exists)
    return Object.entries(regionData).reduce((total, [regionName, region]) => {
      // Skip TOTAL row
      if (regionName === "TOTAL" || regionName === "Total") return total;
      
      const rawValue = region[mapYear];
      const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
      const count = parseInt(cleanValue, 10);
      return total + (isNaN(count) ? 0 : count);
    }, 0);
  }, [regionData, mapYear]);
  // 🟦 Max value for shading intensity
  const maxCount = Math.max(
    ...Object.values(regionData).map(r => parseInt(r[mapYear] || 0, 10)),
    0
  );

  // 🟡 Fill color based on count
  const getRegionFill = (count) => {
    if (!count || count === 0) return "#EEE";
    const intensity = count / maxCount;
    const red = Math.floor(255 - intensity * 100);
    const green = Math.floor(235 - intensity * 200);
    return `rgb(${red}, ${green}, 150)`;
  };

  // 📍 Approximate centroids for labels
  const regionCentroids = {
    "National Capital Region": [121.0, 14.6],
    "Ilocos": [120.5, 17.5],
    "Cagayan Valley": [121.7, 17.0],
    "Central Luzon": [120.8, 15.1],
    "Calabarzon": [121.1, 14.2],
    "Mimaropa": [121.5, 11.5],
    "Bicol": [123.5, 13.0],
    "Western Visayas": [122.6, 10.7],
    "Central Visayas": [123.9, 10.2],
    "Eastern Visayas": [125.0, 11.5],
    "Zamboanga Peninsula": [122.0, 7.1],
    "Northern Mindanao": [124.5, 8.0],
    "Davao": [125.6, 7.3],
    "Soccsksargen": [124.8, 6.9],
    "Caraga": [126.0, 8.7],
    "Autonomous Region in Muslim Mindanao": [124.3, 7.2],
    "Cordillera Administrative Region": [121.1, 17.3],
  };

  if (loading) {
    return (
      <Layout>
        <main style={{ flex: 1, padding: "2rem", background: "#ecf0f1", marginTop: 0, display: "flex", justifyContent: "center", alignItems: "center" }}>
          <div style={{ fontSize: "20px", color: "#555" }}>Loading data...</div>
        </main>
      </Layout>
    );
  }

  return (
    <Layout>
      <main style={{ flex: 1, padding: "2rem", background: "#ecf0f1", marginTop: 0 }}>
        <h1>Filipino Emigrants Dashboard</h1>
<p>Welcome! Below are visualizations from the emigrants dataset.</p>

{/* ======================= INSIGHT CARDS ======================= */}
<div style={{ 
  display: "grid", 
  gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", 
  gap: "15px", 
  marginTop: "20px" 
}}>
  {/* Total Emigrants */}
  <div style={{ 
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)", 
    color: "#fff", 
    padding: "20px", 
    borderRadius: "12px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
  }}>
    <div style={{ fontSize: "12px", opacity: 0.9, marginBottom: "5px" }}>Total Emigrants by Region</div>
    <div style={{ fontSize: "28px", fontWeight: "bold", marginBottom: "5px" }}>
      {insights.totalEmigrants.toLocaleString()}
    </div>
    <div style={{ fontSize: "11px", opacity: 0.8 }}>in {insights.latestYear}</div>
  </div>

  {/* Top Region */}
  <div style={{ 
    background: "linear-gradient(135deg, #f093fb 0%, #f5576c 100%)", 
    color: "#fff", 
    padding: "20px", 
    borderRadius: "12px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
  }}>
    <div style={{ fontSize: "12px", opacity: 0.9, marginBottom: "5px" }}>Top Region</div>
    <div style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "5px" }}>
      {insights.topRegion.name}
    </div>
    <div style={{ fontSize: "11px", opacity: 0.8 }}>
      {insights.topRegion.count.toLocaleString()} emigrants
    </div>
  </div>

  {/* Top Age Group */}
  <div style={{ 
    background: "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)", 
    color: "#fff", 
    padding: "20px", 
    borderRadius: "12px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
  }}>
    <div style={{ fontSize: "12px", opacity: 0.9, marginBottom: "5px" }}>Most Common Age</div>
    <div style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "5px" }}>
      {insights.topAgeGroup.name}
    </div>
    <div style={{ fontSize: "11px", opacity: 0.8 }}>
      {insights.topAgeGroup.count.toLocaleString()} emigrants
    </div>
  </div>

  {/* Dominant Sex */}
  <div style={{ 
    background: "linear-gradient(135deg, #fa709a 0%, #fee140 100%)", 
    color: "#fff", 
    padding: "20px", 
    borderRadius: "12px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
  }}>
    <div style={{ fontSize: "12px", opacity: 0.9, marginBottom: "5px" }}>Dominant Sex</div>
    <div style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "5px" }}>
      {insights.dominantSex.name}
    </div>
    <div style={{ fontSize: "11px", opacity: 0.8 }}>
      {insights.dominantSex.percentage}% of total
    </div>
  </div>

  {/* Year-over-Year Change */}
  <div style={{ 
    background: insights.yearOverYearChange >= 0 
      ? "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)" 
      : "linear-gradient(135deg, #fa8072 0%, #ff6b6b 100%)", 
    color: "#fff", 
    padding: "20px", 
    borderRadius: "12px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
  }}>
    <div style={{ fontSize: "12px", opacity: 0.9, marginBottom: "5px" }}>YoY Change base on Region</div>
    <div style={{ fontSize: "28px", fontWeight: "bold", marginBottom: "5px" }}>
      {insights.yearOverYearChange >= 0 ? '+' : ''}
      {insights.yearOverYearChange.toFixed(1)}%
    </div>
    <div style={{ fontSize: "11px", opacity: 0.8 }}>
      vs previous year
    </div>

    
  </div>

  {/* Top Civil Status */}
  <div style={{ 
    background: "linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)", 
    color: "#333", 
    padding: "20px", 
    borderRadius: "12px",
    boxShadow: "0 4px 6px rgba(0,0,0,0.1)"
  }}>
    <div style={{ fontSize: "12px", opacity: 0.8, marginBottom: "5px" }}>Most Common Status</div>
    <div style={{ fontSize: "20px", fontWeight: "bold", marginBottom: "5px" }}>
      {insights.topCivilStatus.name}
    </div>
    <div style={{ fontSize: "11px", opacity: 0.7 }}>
      {insights.topCivilStatus.count.toLocaleString()} emigrants
    </div>
  </div>
</div>

        {/* ======================= CHARTS ROW ======================= */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", marginTop: "20px" }}>
          {/* Bar Chart - Age Groups */}
          <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
              <h3 style={{ margin: 0 }}>Comparison: Age Groups</h3>
              <div>
                <label htmlFor="age-year" style={{ marginRight: "8px", fontSize: "14px" }}>Year:</label>
                <select
                  id="age-year"
                  value={ageYear}
                  onChange={(e) => setAgeYear(e.target.value)}
                  style={{ padding: "5px 10px", fontSize: "14px", borderRadius: "4px", border: "1px solid #ccc" }}
                >
                  {availableYears.map(y => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
            </div>
            {processedAgeData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <BarChart data={processedAgeData}>
                  <XAxis dataKey="ageGroup" angle={-45} textAnchor="end" height={80} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="count" fill="#3498db" name="Emigrants" />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p style={{ textAlign: "center", color: "#999" }}>No age data available</p>
            )}
          </div>

          {/* Pie Chart - Sex */}
          <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
              <h3 style={{ margin: 0 }}>Composition: Sex</h3>
              <div>
                <label htmlFor="sex-year" style={{ marginRight: "8px", fontSize: "14px" }}>Year:</label>
                <select
                  id="sex-year"
                  value={sexYear}
                  onChange={(e) => setSexYear(e.target.value)}
                  style={{ padding: "5px 10px", fontSize: "14px", borderRadius: "4px", border: "1px solid #ccc" }}
                >
                  {availableYears.map(y => (
                    <option key={y} value={y}>{y}</option>
                  ))}
                </select>
              </div>
            </div>
            {processedSexData.length > 0 ? (
              <>
                <ResponsiveContainer width="100%" height={250}>
                  <PieChart>
                    <Pie
                      data={processedSexData.sort((a, b) => b.count - a.count)}
                      dataKey="count"
                      nameKey="sex"
                      outerRadius={100}
                      innerRadius={60}
                      startAngle={90}
                      endAngle={-270}
                      label
                    >
                      {processedSexData.map((_, i) => (
                        <Cell key={i} fill={COLORS[i % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
                <div style={{ textAlign: "center", marginTop: "-130px", position: "relative", zIndex: 1 }}>
                  <div style={{ fontSize: "12px", color: "#666", fontWeight: "bold" }}>TOTAL</div>
                  <div style={{ fontSize: "20px", color: "#2c3e50", fontWeight: "bold" }}>
                    {processedSexData.reduce((sum, item) => sum + item.count, 0).toLocaleString()}
                  </div>
                </div>
              </>
            ) : (
              <p style={{ textAlign: "center", color: "#999" }}>No sex data available</p>
            )}
          </div>

         {/* Line Chart - Trends over time */}
          <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
              <h3 style={{ margin: 0 }}>{trendsTitle}</h3>
              <div>
                <label htmlFor="trends-dataset" style={{ marginRight: "8px", fontSize: "14px" }}>Dataset:</label>
                <select
                  id="trends-dataset"
                  value={trendsDataset}
                  onChange={(e) => setTrendsDataset(e.target.value)}
                  style={{ padding: "5px 10px", fontSize: "14px", borderRadius: "4px", border: "1px solid #ccc" }}
                >
                  <option value="sex">Sex (Total)</option>
                  <option value="age">Age Groups</option>
                  <option value="region">Region</option>
                </select>
              </div>
            </div>
            {timelineData.length > 0 ? (
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={timelineData}>
                  <XAxis dataKey="year" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="count" stroke="#2980b9" name="Total Emigrants" />
                </LineChart>
              </ResponsiveContainer>
            ) : (
              <p style={{ textAlign: "center", color: "#999" }}>No timeline data available</p>
            )}
          </div>

        {/* Bar Chart - Civil Status Distribution */}
        <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
            <h3 style={{ margin: 0 }}>Distribution: Civil Status</h3>
            <div>
              <label htmlFor="civil-status-year" style={{ marginRight: "8px", fontSize: "14px" }}>Year:</label>
              <select
                id="civil-status-year"
                value={civilStatusYear}
                onChange={(e) => setCivilStatusYear(e.target.value)}
                style={{ padding: "5px 10px", fontSize: "14px", borderRadius: "4px", border: "1px solid #ccc" }}
              >
                {availableYears.map(y => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>
          </div>
          {processedCivilStatusData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={processedCivilStatusData}>
                <XAxis dataKey="category" angle={-45} textAnchor="end" height={80} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#e74c3c" name="Emigrants" />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p style={{ textAlign: "center", color: "#999" }}>No civil status data available</p>
          )}
        </div>

       {/* Interactive Heatmap */}
<div style={{ background: "#fff", padding: "1rem", borderRadius: "8px", gridColumn: "1 / -1" }}>
  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem" }}>
    <h3 style={{ margin: 0 }}>Heatmap: Emigration Intensity Over Time</h3>
    <div>
      <label htmlFor="heatmap-dataset" style={{ marginRight: "8px", fontSize: "14px" }}>Dataset:</label>
      <select
        id="heatmap-dataset"
        value={heatmapDataset}
        onChange={(e) => setHeatmapDataset(e.target.value)}
        style={{ padding: "5px 10px", fontSize: "14px", borderRadius: "4px", border: "1px solid #ccc" }}
      >
        <option value="age">Age Groups × Year</option>
        <option value="civil">Civil Status × Year</option>
        <option value="region">Region × Year</option>
      </select>
    </div>
  </div>

  <div style={{ overflowX: "auto" }}>
    <table style={{ 
      width: "100%", 
      borderCollapse: "collapse", 
      fontSize: "12px",
      minWidth: "800px"
    }}>
      <thead>
        <tr>
          <th style={{ 
            padding: "10px", 
            textAlign: "left", 
            borderBottom: "2px solid #ddd",
            position: "sticky",
            left: 0,
            background: "#fff",
            zIndex: 2,
            fontWeight: "bold"
          }}>
            {heatmapDataset === "age" ? "Age Group" : heatmapDataset === "civil" ? "Civil Status" : "Region"}
          </th>
          {availableYears.map(year => (
            <th key={year} style={{ 
              padding: "10px", 
              textAlign: "center", 
              borderBottom: "2px solid #ddd",
              fontWeight: "bold"
            }}>
              {year}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {/* Render based on selected dataset */}
        {heatmapDataset === "age" && ageData
  .filter((item, index) => {
    const ageGroup = item["AGE GROUP"] || item[" AGE GROUP"];
    // Keep only rows with actual age group values
    return ageGroup && ageGroup.trim() !== "";
  })
  .map((item, index) => {
    const category = item["AGE GROUP"] || item[" AGE GROUP"];
          // Calculate max value for this category across all years
          const categoryMax = Math.max(
            ...availableYears.map(year => {
              const rawValue = item[year];
              const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
              return parseInt(cleanValue, 10) || 0;
            })
          );

          return (
            <tr key={category}>
              <td style={{ 
                padding: "10px", 
                borderBottom: "1px solid #eee",
                fontWeight: "500",
                position: "sticky",
                left: 0,
                background: "#fff",
                zIndex: 1
              }}>
                {category}
              </td>
              {availableYears.map(year => {
                const rawValue = item[year];
                const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
                const count = parseInt(cleanValue, 10) || 0;
                
                // Calculate color intensity (0-1)
                const intensity = categoryMax > 0 ? count / categoryMax : 0;
                
                // Generate color from light to dark
                const red = Math.floor(255 - intensity * 100);
                const green = Math.floor(235 - intensity * 180);
                const blue = Math.floor(200 - intensity * 50);
                const backgroundColor = `rgb(${red}, ${green}, ${blue})`;
                
                // Text color based on intensity
                const textColor = intensity > 0.5 ? '#fff' : '#333';

                return (
                  <td key={year} style={{ 
                    padding: "10px", 
                    textAlign: "center", 
                    borderBottom: "1px solid #eee",
                    backgroundColor,
                    color: textColor,
                    fontWeight: intensity > 0.7 ? "bold" : "normal",
                    transition: "all 0.2s",
                    cursor: "pointer"
                  }}
                  title={`${category} (${year}): ${count.toLocaleString()}`}
                  >
                    {count > 0 ? count.toLocaleString() : '-'}
                  </td>
                );
              })}
            </tr>
          );
        })}

        {/* Civil Status Heatmap */}
        {heatmapDataset === "civil" && civilStatusData
          .sort((a, b) => {
            const yearA = (a["YEAR"] || a[" YEAR"] || a["  YEAR"] || "").toString().replace(/["'\s]/g, "");
            const yearB = (b["YEAR"] || b[" YEAR"] || b["  YEAR"] || "").toString().replace(/["'\s]/g, "");
            return parseInt(yearA) - parseInt(yearB);
          })
          .map((yearDoc) => {
            const year = yearDoc["YEAR"] || yearDoc[" YEAR"] || yearDoc["  YEAR"];
            const cleanYear = year ? String(year).replace(/["'\s]/g, "") : "";
            
            if (!cleanYear || !/^\d{4}$/.test(cleanYear)) return null;

            return null; // We'll render by category, not by year
          })}

        {heatmapDataset === "civil" && (() => {
          const categories = ["Single", "Married", "Divorced", "Separated", "Widower", "Not Reported"];
          
          return categories.map(category => {
            // Calculate max value for this category across all years
            const categoryMax = Math.max(
              ...civilStatusData.map(yearDoc => {
                const value = yearDoc[category] || yearDoc[` ${category}`] || yearDoc[`  ${category}`];
                const cleanValue = value ? String(value).replace(/["\s,]/g, "") : "0";
                return parseInt(cleanValue, 10) || 0;
              })
            );

            return (
              <tr key={category}>
                <td style={{ 
                  padding: "10px", 
                  borderBottom: "1px solid #eee",
                  fontWeight: "500",
                  position: "sticky",
                  left: 0,
                  background: "#fff",
                  zIndex: 1
                }}>
                  {category}
                </td>
                {availableYears.map(year => {
                  // Find the document for this year
                  const yearDoc = civilStatusData.find(item => {
                    const docYear = item["YEAR"] || item[" YEAR"] || item["  YEAR"];
                    const cleanDocYear = docYear ? String(docYear).replace(/["'\s]/g, "") : "";
                    return cleanDocYear === year;
                  });

                  if (!yearDoc) {
                    return (
                      <td key={year} style={{ 
                        padding: "10px", 
                        textAlign: "center", 
                        borderBottom: "1px solid #eee",
                        backgroundColor: "#f5f5f5",
                        color: "#999"
                      }}>
                        -
                      </td>
                    );
                  }

                  const value = yearDoc[category] || yearDoc[` ${category}`] || yearDoc[`  ${category}`];
                  const cleanValue = value ? String(value).replace(/["\s,]/g, "") : "0";
                  const count = parseInt(cleanValue, 10) || 0;
                  
                  // Calculate color intensity (0-1)
                  const intensity = categoryMax > 0 ? count / categoryMax : 0;
                  
                  // Generate color from light to dark
                  const red = Math.floor(255 - intensity * 100);
                  const green = Math.floor(235 - intensity * 180);
                  const blue = Math.floor(200 - intensity * 50);
                  const backgroundColor = `rgb(${red}, ${green}, ${blue})`;
                  
                  // Text color based on intensity
                  const textColor = intensity > 0.5 ? '#fff' : '#333';

                  return (
                    <td key={year} style={{ 
                      padding: "10px", 
                      textAlign: "center", 
                      borderBottom: "1px solid #eee",
                      backgroundColor,
                      color: textColor,
                      fontWeight: intensity > 0.7 ? "bold" : "normal",
                      transition: "all 0.2s",
                      cursor: "pointer"
                    }}
                    title={`${category} (${year}): ${count.toLocaleString()}`}
                    >
                      {count > 0 ? count.toLocaleString() : '-'}
                    </td>
                  );
                })}
              </tr>
            );
          });
        })()}

       {/* Region Heatmap */}
      {heatmapDataset === "region" && Object.entries(regionData)
        .filter(([regionName]) => {
          const cleanName = regionName.toUpperCase().trim();
          return cleanName !== "TOTAL" && cleanName !== "TOTAL:";
        })
                .sort((a, b) => a[0].localeCompare(b[0]))
          .map(([regionName, regionInfo]) => {
            // Calculate max value for this region across all years
            const regionMax = Math.max(
              ...availableYears.map(year => {
                const rawValue = regionInfo[year];
                const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
                return parseInt(cleanValue, 10) || 0;
              })
            );

            return (
              <tr key={regionName}>
                <td style={{ 
                  padding: "10px", 
                  borderBottom: "1px solid #eee",
                  fontWeight: "500",
                  position: "sticky",
                  left: 0,
                  background: "#fff",
                  zIndex: 1,
                  fontSize: "11px"
                }}>
                  {regionName.replace(/Region [IVX]+ - /g, '').replace(/Region [0-9]+ - /g, '')}
                </td>
                {availableYears.map(year => {
                  const rawValue = regionInfo[year];
                  const cleanValue = rawValue ? String(rawValue).replace(/["\s,]/g, "") : "0";
                  const count = parseInt(cleanValue, 10) || 0;
                  
                  // Calculate color intensity (0-1)
                  const intensity = regionMax > 0 ? count / regionMax : 0;
                  
                  // Generate color from light to dark
                  const red = Math.floor(255 - intensity * 100);
                  const green = Math.floor(235 - intensity * 180);
                  const blue = Math.floor(200 - intensity * 50);
                  const backgroundColor = `rgb(${red}, ${green}, ${blue})`;
                  
                  // Text color based on intensity
                  const textColor = intensity > 0.5 ? '#fff' : '#333';

                  return (
                    <td key={year} style={{ 
                      padding: "10px", 
                      textAlign: "center", 
                      borderBottom: "1px solid #eee",
                      backgroundColor,
                      color: textColor,
                      fontWeight: intensity > 0.7 ? "bold" : "normal",
                      transition: "all 0.2s",
                      cursor: "pointer"
                    }}
                    title={`${regionName} (${year}): ${count.toLocaleString()}`}
                    >
                      {count > 0 ? count.toLocaleString() : '-'}
                    </td>
                  );
                })}
              </tr>
            );
          })}
      </tbody>
    </table>
  </div>
  
  {/* Legend */}
  <div style={{ 
    marginTop: "15px", 
    display: "flex", 
    alignItems: "center", 
    justifyContent: "center",
    gap: "10px"
  }}>
    <span style={{ fontSize: "12px", color: "#666" }}>Low</span>
    <div style={{ display: "flex", height: "20px" }}>
      {[0, 0.2, 0.4, 0.6, 0.8, 1].map((intensity, i) => {
        const red = Math.floor(255 - intensity * 100);
        const green = Math.floor(235 - intensity * 180);
        const blue = Math.floor(200 - intensity * 50);
        return (
          <div key={i} style={{ 
            width: "40px", 
            backgroundColor: `rgb(${red}, ${green}, ${blue})`,
            border: "1px solid #ddd"
          }} />
        );
      })}
    </div>
    <span style={{ fontSize: "12px", color: "#666" }}>High</span>
  </div>
</div>
        </div>



        {/* ======================= MAP SECTION ======================= */}
        <div style={{ background: "#fff", padding: "1rem", borderRadius: "8px", marginTop: "20px" }}>
          <h3>Geographic Representation by Region</h3>

          {/* Year Dropdown for Map */}
          <div style={{ marginBottom: "1rem" }}>
            <label htmlFor="map-year-select" style={{ marginRight: "8px", fontWeight: "bold" }}>Select Year: </label>
            <select
              id="map-year-select"
              value={mapYear}
              onChange={(e) => setMapYear(e.target.value)}
              style={{ padding: "5px 10px", fontSize: "14px", borderRadius: "4px", border: "1px solid #ccc" }}
            >
              {availableYears.map(y => (
                <option key={y} value={y}>{y}</option>
              ))}
            </select>
          </div>

          {/* Total Emigrants Counter */}
          <div style={{
            background: "#f0f4f8",
            padding: "10px 15px",
            borderRadius: "6px",
            marginBottom: "1rem",
            display: "inline-block",
            boxShadow: "0 1px 4px rgba(0,0,0,0.1)"
          }}>
            <strong>Total Emigrants ({mapYear}): </strong>
            <span style={{ fontSize: "18px", color: "#2c3e50" }}>
              {totalEmigrants.toLocaleString()}
            </span>
          </div>

          {/* Map */}
          <ComposableMap
            projection="geoMercator"
            projectionConfig={{ scale: 3500, center: [122, 12] }}
            width={800}
            height={900}
          >
            {/* 🟦 Region Shapes */}
            <Geographies geography={geoData}>
            {({ geographies }) =>
              geographies.map((geo) => {
                const geoName = geo.properties.name.trim();
                const firebaseRegionKey = regionNameMap[geoName];
                const regionInfo = regionData[firebaseRegionKey];
                const rawValue = regionInfo ? regionInfo[mapYear] : null;
                const count = rawValue ? parseInt(String(rawValue).replace(/["\s,]/g, ""), 10) : 0;
                  return (
                    <Geography
                      key={geo.rsmKey}
                      geography={geo}
                      fill={getRegionFill(count)}
                      stroke="#D6D6DA"
                      style={{
                        default: { outline: "none" },
                        hover: { fill: "#2ecc71", outline: "none" },
                        pressed: { outline: "none" },
                      }}
                    />
                  );
                })
              }
            </Geographies>

            {/* 🟡 Labels: Region Name + Count */}
            {Object.keys(regionNameMap).map((geoName) => {
            const firebaseRegionKey = regionNameMap[geoName];
            const regionInfo = regionData[firebaseRegionKey];
            const rawValue = regionInfo ? regionInfo[mapYear] : null;
            const count = rawValue ? parseInt(String(rawValue).replace(/["\s,]/g, ""), 10) : 0;
              if (!regionInfo) return null;

              const centroid = regionCentroids[geoName];
              if (!centroid) return null;

              const [avgX, avgY] = centroid;

              return (
                <Marker key={geoName} coordinates={[avgX, avgY]}>
                  <g>
                    <text
                      textAnchor="middle"
                      y={-8}
                      style={{
                        fontSize: "8px",
                        fontWeight: "bold",
                        fill: "#fff",
                        stroke: "#fff",
                        strokeWidth: 3,
                      }}
                    >
                      {geoName}
                    </text>
                    <text
                      textAnchor="middle"
                      y={-8}
                      style={{
                        fontSize: "8px",
                        fontWeight: "bold",
                        fill: "#222",
                      }}
                    >
                      {geoName}
                    </text>

                    <text
                      textAnchor="middle"
                      y={6}
                      style={{
                        fontSize: "8px",
                        fontWeight: "bold",
                        fill: "#fff",
                        stroke: "#fff",
                        strokeWidth: 3,
                      }}
                    >
                      {count ? count.toLocaleString() : "0"}
                    </text>
                    <text
                      textAnchor="middle"
                      y={6}
                      style={{
                        fontSize: "8px",
                        fontWeight: "bold",
                        fill: count > 0 ? "#000" : "#666",
                      }}
                    >
                      {count ? count.toLocaleString() : "0"}
                    </text>
                  </g>
                </Marker>
              );
            })}
          </ComposableMap>
        </div>
      </main>
    </Layout>
  );
}