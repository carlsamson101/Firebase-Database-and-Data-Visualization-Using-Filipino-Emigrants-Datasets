// src/App.jsx
import React, { useState } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import ImportCSV from "./pages/ImportCSV.jsx";
import Dataset from "./pages/Dataset.jsx"; // 👈 new page

export default function App() {
  const [loggedIn, setLoggedIn] = useState(false);

  return (
    <>
      <style>{`
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }

        body, html {
          margin: 0;
          padding: 0;
          height: 100%;
          overflow-x: hidden;
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        }

        #root {
          height: 100vh;
          display: flex;
          flex-direction: column;
        }

        /* Remove default browser styling */
        button {
          font-family: inherit;
        }
        
        input {
          font-family: inherit;
        }

        /* Ensure seamless layout */
        .app-container {
          display: flex;
          height: 100vh;
          width: 100%;
        }

        /* Fix any potential gaps in flex layouts */
        .main-content {
          flex: 1;
          display: flex;
          flex-direction: column;
          min-height: 100vh;
        }

        /* Remove any unwanted margins from common elements */
        h1, h2, h3, h4, h5, h6, p, ul, ol, li {
          margin: 0;
          padding: 0;
        }

        /* Ensure components take full space without gaps */
        aside, main {
          display: flex;
          flex-direction: column;
        }
      `}</style>
      
      <BrowserRouter>
        <Routes>
          {/* Login / Root */}
          <Route
            path="/"
            element={
              loggedIn ? (
                <Navigate to="/dashboard" />
              ) : (
                <Login setLoggedIn={setLoggedIn} />
              )
            }
          />

          {/* Dashboard */}
          <Route
            path="/dashboard"
            element={
              loggedIn ? (
                <Dashboard setLoggedIn={setLoggedIn} />
              ) : (
                <Navigate to="/" />
              )
            }
          />

          {/* CSV Import Page */}
          <Route
            path="/import"
            element={loggedIn ? <ImportCSV /> : <Navigate to="/" />}
          />

          {/* Dataset Viewer */}
          <Route
            path="/dataset/:name"
            element={loggedIn ? <Dataset /> : <Navigate to="/" />}
          />
        </Routes>
      </BrowserRouter>
    </>
  );
}